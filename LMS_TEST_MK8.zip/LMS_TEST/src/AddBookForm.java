import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.net.URL;


public class AddBookForm {

    private JFrame frame;
    private Connection connection;
    private String fullName;

    public static void showDashboard(String fullName) {
        SwingUtilities.invokeLater(() -> new AddBookForm(fullName));
    }

    public AddBookForm(String fullname) {
        this.fullName = fullname;
        initialize();
        connectToDatabase();
    }

    private void connectToDatabase() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/librarysystem", "root", "root");
            System.out.println("Connected to database successfully!");
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(frame, "MySQL JDBC Driver not found!", "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Connection failed! Check database credentials.", "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void initialize() {
        frame = new JFrame("Add Book");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(1000, 800);
        frame.setLayout(new BorderLayout());

        frame.add(createSidebarPanel(), BorderLayout.WEST);
        frame.add(createFormPanel(), BorderLayout.CENTER);

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

private JPanel createSidebarPanel() {
    JPanel sidebar = new JPanel();
    sidebar.setBackground(Color.DARK_GRAY);
    sidebar.setPreferredSize(new Dimension(250, frame.getHeight()));
    sidebar.setLayout(new BorderLayout());

    JPanel topPanel = new JPanel();
    topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
    topPanel.setBackground(Color.DARK_GRAY);

    JLabel title = new JLabel("DASHBOARD", SwingConstants.CENTER);
    title.setForeground(Color.WHITE);
    title.setFont(new Font("Arial", Font.BOLD, 22));
    title.setAlignmentX(Component.CENTER_ALIGNMENT);
    title.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
    topPanel.add(title);

    try {
        URL logoUrl = getClass().getResource("mapua_logo.png");
        if (logoUrl != null) {
            ImageIcon originalIcon = new ImageIcon(logoUrl);
            Image scaledImage = originalIcon.getImage().getScaledInstance(150, 100, Image.SCALE_SMOOTH);
            JLabel logo = new JLabel(new ImageIcon(scaledImage));
            logo.setAlignmentX(Component.CENTER_ALIGNMENT);
            JPanel logoPanel = new JPanel();
            logoPanel.setBackground(Color.DARK_GRAY);
            logoPanel.add(logo);
            topPanel.add(logoPanel);
        }
    } catch (Exception e) {
        System.err.println("Error loading logo: " + e.getMessage());
    }

    JPanel centerPanel = new JPanel();
    centerPanel.setBackground(Color.DARK_GRAY);
    centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
    centerPanel.setBorder(BorderFactory.createEmptyBorder(100, 20, 100, 20));

    JButton manageBooksBtn = createSidebarButton("Manage Books");
    JButton bookStatusBtn = createSidebarButton("Book Status");
    JButton manageAccountsBtn = createSidebarButton("Manage Accounts");

    centerPanel.add(manageBooksBtn);
    centerPanel.add(Box.createRigidArea(new Dimension(0, 20)));
    centerPanel.add(bookStatusBtn);
    centerPanel.add(Box.createRigidArea(new Dimension(0, 20)));
    centerPanel.add(manageAccountsBtn);

    JPanel logoutPanel = new JPanel();
    logoutPanel.setBackground(Color.DARK_GRAY);
    logoutPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
    logoutPanel.setLayout(new BoxLayout(logoutPanel, BoxLayout.Y_AXIS));

    JButton logoutBtn = new JButton("LOGOUT");
    logoutBtn.setFont(new Font("Arial", Font.BOLD, 16));
    logoutBtn.setMaximumSize(new Dimension(200, 40));
    logoutBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
    logoutBtn.setBackground(Color.WHITE);
    logoutBtn.setFocusPainted(false);
    logoutBtn.addActionListener(e -> {
        try {
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        frame.dispose();
        SwingUtilities.invokeLater(() -> {
            Login_Page login = new Login_Page();
            login.setVisible(true);
        });
    });

    logoutPanel.add(logoutBtn);

    // Add button actions
    manageBooksBtn.addActionListener(e -> {
        frame.dispose();
        LibrarianDashboard.showDashboard(fullName);
    });

    bookStatusBtn.addActionListener(e -> {
        frame.dispose();
        new BookStatusPage(fullName);
    });

    manageAccountsBtn.addActionListener(e -> {
        frame.dispose();
        new ManageAccount(fullName);
    });

    sidebar.add(topPanel, BorderLayout.NORTH);
    sidebar.add(centerPanel, BorderLayout.CENTER);
    sidebar.add(logoutPanel, BorderLayout.SOUTH);

    return sidebar;
}

    private JButton createSidebarButton(String text) {
        JButton button = new JButton(text);
        button.setMaximumSize(new Dimension(200, 40));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setFont(new Font("Arial", Font.PLAIN, 16));
        button.setFocusPainted(false);
        return button;
    }

    private JPanel createFormPanel() {
        JPanel formPanel = new JPanel() {
        Image bgImage = new ImageIcon(getClass().getResource("mapua_bg.png")).getImage();

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(bgImage, 0, 0, getWidth(), getHeight(), this);
    }
};
    formPanel.setOpaque(false);

        formPanel.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        Font labelFont = new Font("Arial", Font.PLAIN, 16);
        Font inputFont = new Font("Arial", Font.PLAIN, 16);

        String[] labels = {"ISBN:", "Book Title:", "Author:", "Category:", "Publisher:", "Publish Date (YYYY-MM-DD):", "Book Overview:"};
        JTextField[] fields = new JTextField[labels.length - 1];
        JTextArea overviewArea = new JTextArea(5, 20);
        overviewArea.setFont(inputFont);
        overviewArea.setLineWrap(true);
        overviewArea.setWrapStyleWord(true);

        for (int i = 0; i < labels.length; i++) {
            gbc.gridx = 0;
            gbc.gridy = i;
            gbc.anchor = GridBagConstraints.EAST;

            JLabel label = new JLabel(labels[i]);
            label.setFont(labelFont);
            formPanel.add(label, gbc);

            gbc.gridx = 1;
            gbc.anchor = GridBagConstraints.WEST;

            if (i < labels.length - 1) {
                fields[i] = new JTextField(20);
                fields[i].setFont(inputFont);
                formPanel.add(fields[i], gbc);
            } else {
                JScrollPane scrollPane = new JScrollPane(overviewArea);
                scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
                formPanel.add(scrollPane, gbc);
            }
        }

        JButton addButton = new JButton("ADD BOOK");
        addButton.setFont(new Font("Arial", Font.BOLD, 18));
        addButton.setBackground(Color.WHITE);
        addButton.setFocusPainted(false);
        addButton.setPreferredSize(new Dimension(160, 40));
        addButton.addActionListener((ActionEvent e) -> {
            try {
                String isbn = fields[0].getText().trim();
                String bookTitle = fields[1].getText().trim();
                String author = fields[2].getText().trim();
                String category = fields[3].getText().trim();
                String publisher = fields[4].getText().trim();
                String publishDateStr = fields[5].getText().trim();
                String overview = overviewArea.getText().trim();

                Date publishDate = null;
                if (!publishDateStr.isEmpty()) {
                    try {
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                        java.util.Date date = sdf.parse(publishDateStr);
                        publishDate = new Date(date.getTime());
                    } catch (ParseException ex) {
                        JOptionPane.showMessageDialog(frame, "Invalid date format! Please use YYYY-MM-DD", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                String sql = "INSERT INTO LibraryMaterial (BookName, Authors, PublishedDate, CategoryName, Publisher, ISBN, Overview) VALUES (?, ?, ?, ?, ?, ?, ?)";
                try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                    pstmt.setString(1, bookTitle);
                    pstmt.setString(2, author);
                    if (publishDate != null) {
                        pstmt.setDate(3, publishDate);
                    } else {
                        pstmt.setNull(3, Types.DATE);
                    }
                    pstmt.setString(4, category);
                    pstmt.setString(5, publisher);
                    pstmt.setString(6, isbn);
                    pstmt.setString(7, overview);

                    int affectedRows = pstmt.executeUpdate();

                    if (affectedRows > 0) {
                        JOptionPane.showMessageDialog(frame, "Book added successfully!");
                        for (JTextField field : fields) {
                            field.setText("");
                        }
                        overviewArea.setText("");
                    } else {
                        JOptionPane.showMessageDialog(frame, "Failed to add book!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(frame, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });

        gbc.gridx = 1;
        gbc.gridy = labels.length;
        gbc.anchor = GridBagConstraints.CENTER;
        formPanel.add(addButton, gbc);

// Back to Dashboard Button (below)
    JButton backButton = new JButton("BACK TO DASHBOARD");
    backButton.setFont(new Font("Arial", Font.BOLD, 16));
    backButton.setBackground(Color.WHITE);
    backButton.setFocusPainted(false);
    backButton.setPreferredSize(new Dimension(220, 40)); // Wider to fit full text
    backButton.addActionListener(e -> {
        frame.dispose();
        LibrarianDashboard.showDashboard(fullName);
});

        gbc.gridy = labels.length + 1;
        formPanel.add(backButton, gbc);


        return formPanel;
    }

    @Override
    protected void finalize() throws Throwable {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        super.finalize();
    }
}
