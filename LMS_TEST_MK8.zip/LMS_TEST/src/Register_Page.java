import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Register_Page extends JFrame {

    private JTextField txtFullName, txtIdNumber;
    private JPasswordField txtPassword, txtConfirmPassword;
    private JComboBox<String> cmbRole;
    private JCheckBox chkShowPassword;
    private JButton btnRegister, btnBack;

    public Register_Page() {
        setTitle("Register New User");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        ImageIcon bgIcon = new ImageIcon(getClass().getResource("login_bg.png"));
        JLabel bg = new JLabel(bgIcon);
        int frameWidth = bgIcon.getIconWidth();
        int frameHeight = bgIcon.getIconHeight();
        setContentPane(bg);
        bg.setLayout(null);
        setSize(frameWidth, frameHeight);
        setLocationRelativeTo(null);

        Font labelFont = new Font("Arial", Font.BOLD, 18);
        Font inputFont = new Font("Arial", Font.PLAIN, 16);

        int labelWidth = 160;
        int fieldWidth = 250;
        int fieldHeight = 30;
        int rowGap = 45;

        // Centered horizontally in the whole frame
        int totalRows = 6;
        int totalHeight = (totalRows * rowGap) + 40 + 80;
        int startY = (frameHeight - totalHeight) / 2;
        int centerX = (frameWidth - (labelWidth + fieldWidth + 10)) / 2;
        int labelX = centerX;
        int fieldX = labelX + labelWidth + 10;

        JLabel lblTitle = new JLabel("Register User");
        lblTitle.setBounds((frameWidth - 200) / 2, startY - 60, 200, 40);
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 28));
        bg.add(lblTitle);

        int y = startY;

        JLabel lblFullName = new JLabel("Full Name:");
        lblFullName.setBounds(labelX, y, labelWidth, fieldHeight);
        lblFullName.setForeground(Color.WHITE);
        lblFullName.setFont(labelFont);
        bg.add(lblFullName);

        txtFullName = new JTextField();
        txtFullName.setBounds(fieldX, y, fieldWidth, fieldHeight);
        txtFullName.setFont(inputFont);
        bg.add(txtFullName);

        y += rowGap;
        JLabel lblRole = new JLabel("Role:");
        lblRole.setBounds(labelX, y, labelWidth, fieldHeight);
        lblRole.setForeground(Color.WHITE);
        lblRole.setFont(labelFont);
        bg.add(lblRole);

        cmbRole = new JComboBox<>(new String[]{"Student", "Librarian"});
        cmbRole.setBounds(fieldX, y, fieldWidth, fieldHeight);
        cmbRole.setFont(inputFont);
        bg.add(cmbRole);

        y += rowGap;
        JLabel lblIdNumber = new JLabel("ID Number:");
        lblIdNumber.setBounds(labelX, y, labelWidth, fieldHeight);
        lblIdNumber.setForeground(Color.WHITE);
        lblIdNumber.setFont(labelFont);
        bg.add(lblIdNumber);

        txtIdNumber = new JTextField();
        txtIdNumber.setBounds(fieldX, y, fieldWidth, fieldHeight);
        txtIdNumber.setFont(inputFont);
        bg.add(txtIdNumber);

        txtIdNumber.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c) || txtIdNumber.getText().length() >= 11) {
                    e.consume();
                }
            }
        });

        y += rowGap;
        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setBounds(labelX, y, labelWidth, fieldHeight);
        lblPassword.setForeground(Color.WHITE);
        lblPassword.setFont(labelFont);
        bg.add(lblPassword);

        txtPassword = new JPasswordField();
        txtPassword.setBounds(fieldX, y, fieldWidth, fieldHeight);
        txtPassword.setFont(inputFont);
        txtPassword.setEchoChar('•');
        bg.add(txtPassword);

        y += rowGap;
        JLabel lblConfirmPassword = new JLabel("Confirm Password:");
        lblConfirmPassword.setBounds(labelX - 30, y, labelWidth + 20, fieldHeight);
        lblConfirmPassword.setForeground(Color.WHITE);
        lblConfirmPassword.setFont(labelFont);
        bg.add(lblConfirmPassword);

        txtConfirmPassword = new JPasswordField();
        txtConfirmPassword.setBounds(fieldX, y, fieldWidth, fieldHeight);
        txtConfirmPassword.setFont(inputFont);
        txtConfirmPassword.setEchoChar('•');
        bg.add(txtConfirmPassword);

        chkShowPassword = new JCheckBox("Show Password");
        chkShowPassword.setBounds(fieldX, y + 35, fieldWidth, 20);
        chkShowPassword.setForeground(Color.WHITE);
        chkShowPassword.setOpaque(false);
        chkShowPassword.setFont(new Font("Arial", Font.PLAIN, 14));
        bg.add(chkShowPassword);

        chkShowPassword.addActionListener(e -> {
            if (chkShowPassword.isSelected()) {
                txtPassword.setEchoChar((char) 0);
                txtConfirmPassword.setEchoChar((char) 0);
            } else {
                txtPassword.setEchoChar('•');
                txtConfirmPassword.setEchoChar('•');
            }
        });

        y += rowGap + 30;
        btnRegister = new JButton("Register");
        btnRegister.setBounds(fieldX, y, fieldWidth, 40);
        btnRegister.setFont(new Font("Arial", Font.BOLD, 18));
        bg.add(btnRegister);

        y += 50;
        btnBack = new JButton("Back to Login");
        btnBack.setBounds(fieldX, y, fieldWidth, 35);
        btnBack.setFont(new Font("Arial", Font.PLAIN, 14));
        bg.add(btnBack);

        btnRegister.addActionListener(e -> registerUser());
        btnBack.addActionListener(e -> {
            new Login_Page().setVisible(true);
            dispose();
        });
    }

    private void registerUser() {
        String fullName = txtFullName.getText().trim();
        String idNumber = txtIdNumber.getText().trim();
        String password = new String(txtPassword.getPassword()).trim();
        String confirm = new String(txtConfirmPassword.getPassword()).trim();
        String role = (String) cmbRole.getSelectedItem();

        if (fullName.isEmpty() || idNumber.isEmpty() || password.isEmpty() || confirm.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            return;
        }

        if (!idNumber.matches("\\d{1,11}")) {
            JOptionPane.showMessageDialog(this, "ID Number must contain only digits (up to 11).");
            return;
        }

        if (!password.equals(confirm)) {
            JOptionPane.showMessageDialog(this, "Passwords do not match.");
            return;
        }

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/librarysystem", "root", "root");

            String insertUser = "INSERT INTO User (fullname, password, role) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(insertUser, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, fullName);
            stmt.setString(2, password);
            stmt.setString(3, role);
            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            int userId = 0;
            if (rs.next()) userId = rs.getInt(1);

            if (role.equals("Student")) {
                String insertStudent = "INSERT INTO Student (UserID, StudentNumber) VALUES (?, ?)";
                PreparedStatement stmt2 = conn.prepareStatement(insertStudent);
                stmt2.setInt(1, userId);
                stmt2.setString(2, idNumber);
                stmt2.executeUpdate();
            } else if (role.equals("Librarian")) {
                String insertLibrarian = "INSERT INTO Librarian (UserID, EmployeeNumber) VALUES (?, ?)";
                PreparedStatement stmt3 = conn.prepareStatement(insertLibrarian);
                stmt3.setInt(1, userId);
                stmt3.setString(2, idNumber);
                stmt3.executeUpdate();
            }

            JOptionPane.showMessageDialog(this, "Registration successful!");
            new Login_Page().setVisible(true);
            dispose();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Register_Page().setVisible(true));
    }
}
