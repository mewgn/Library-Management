import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.net.URL;
import java.sql.*;

public class DeleteAccPage {
    private JFrame frame;
    private JTable table;
    private DefaultTableModel model;
    private String fullName;
    private int librarianUserID;

    public static void showDashboard(String fullName) {
        SwingUtilities.invokeLater(() -> new DeleteAccPage(fullName));
    }

    public DeleteAccPage(String fullName) {
        this.fullName = fullName;
        initialize();
    }

    private void initialize() {
    frame = new JFrame("Delete Accounts");
    frame.setSize(1200, 700);
    frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    frame.setLayout(new BorderLayout());

    frame.add(createSidebarPanel(), BorderLayout.WEST);

    model = new DefaultTableModel(new String[]{"AccountType", "AccountID", "UserID", "Number"}, 0);
    table = new JTable(model);
    table.setRowHeight(25);
    loadAllAccounts();

    // Create panel for table and buttons
    JPanel centerPanel = new JPanel(new BorderLayout());
    centerPanel.add(new JScrollPane(table), BorderLayout.CENTER);

    JButton deleteBtn = new JButton("Delete Selected Account");
    deleteBtn.setFont(new Font("Arial", Font.BOLD, 16));
    deleteBtn.setPreferredSize(new Dimension(260, 45));
    deleteBtn.setBackground(Color.RED);
    deleteBtn.setForeground(Color.WHITE);
    deleteBtn.addActionListener(e -> deleteSelectedAcc());

    JButton backBtn = new JButton("Back to Dashboard");
    backBtn.setFont(new Font("Arial", Font.PLAIN, 18));
    backBtn.setPreferredSize(new Dimension(200, 45));
    backBtn.addActionListener(e -> {
        frame.dispose();
        ManageAccount.showDashboard(fullName);
    });

    JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 20));
    buttonPanel.setBackground(Color.WHITE);
    buttonPanel.add(deleteBtn);
    buttonPanel.add(backBtn);

    centerPanel.add(buttonPanel, BorderLayout.SOUTH);

    frame.add(centerPanel, BorderLayout.CENTER);

    frame.setLocationRelativeTo(null);
    frame.setVisible(true);
}


    private JPanel createSidebarPanel() {
    JPanel sidebar = new JPanel();
    sidebar.setBackground(Color.DARK_GRAY);
    sidebar.setPreferredSize(new Dimension(250, frame.getHeight()));
    sidebar.setLayout(new BorderLayout());

    JPanel topPanel = new JPanel();
    topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
    topPanel.setBackground(Color.DARK_GRAY);

    JLabel title = new JLabel("DASHBOARD", SwingConstants.CENTER);
    title.setForeground(Color.WHITE);
    title.setFont(new Font("Arial", Font.BOLD, 22));
    title.setAlignmentX(Component.CENTER_ALIGNMENT);
    title.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
    topPanel.add(title);

    try {
        URL logoUrl = getClass().getResource("mapua_logo.png");
        if (logoUrl != null) {
            ImageIcon originalIcon = new ImageIcon(logoUrl);
            Image scaledImage = originalIcon.getImage().getScaledInstance(150, 100, Image.SCALE_SMOOTH);
            JLabel logo = new JLabel(new ImageIcon(scaledImage));
            logo.setAlignmentX(Component.CENTER_ALIGNMENT);
            JPanel logoPanel = new JPanel();
            logoPanel.setBackground(Color.DARK_GRAY);
            logoPanel.add(logo);
            topPanel.add(logoPanel);
        }
    } catch (Exception e) {
        System.err.println("Error loading logo: " + e.getMessage());
    }

    JPanel centerPanel = new JPanel();
    centerPanel.setBackground(Color.DARK_GRAY);
    centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
    centerPanel.setBorder(BorderFactory.createEmptyBorder(100, 20, 100, 20));

    JButton manageBooksBtn = createSidebarButton("Manage Books");
    JButton bookStatusBtn = createSidebarButton("Book Status");
    JButton manageAccountsBtn = createSidebarButton("Manage Accounts");

    centerPanel.add(manageBooksBtn);
    centerPanel.add(Box.createRigidArea(new Dimension(0, 20)));
    centerPanel.add(bookStatusBtn);
    centerPanel.add(Box.createRigidArea(new Dimension(0, 20)));
    centerPanel.add(manageAccountsBtn);

    manageBooksBtn.addActionListener(e -> {
        frame.dispose();
        LibrarianDashboard.showDashboard(fullName);
    });

    bookStatusBtn.addActionListener(e -> {
        frame.dispose();
        new BookStatusPage(fullName);
    });

    manageAccountsBtn.addActionListener(e -> {
        frame.dispose();
        new ManageAccount(fullName);
    });

    JPanel logoutPanel = new JPanel();
    logoutPanel.setBackground(Color.DARK_GRAY);
    logoutPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
    logoutPanel.setLayout(new BoxLayout(logoutPanel, BoxLayout.Y_AXIS));

    JButton logoutBtn = new JButton("LOGOUT");
    logoutBtn.setFont(new Font("Arial", Font.BOLD, 16));
    logoutBtn.setMaximumSize(new Dimension(200, 40));
    logoutBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
    logoutBtn.setBackground(Color.WHITE);
    logoutBtn.setFocusPainted(false);
    logoutBtn.addActionListener(e -> {
        frame.dispose();
        SwingUtilities.invokeLater(() -> {
            Login_Page login = new Login_Page();
            login.setVisible(true);
        });
    });

    logoutPanel.add(logoutBtn);

    sidebar.add(topPanel, BorderLayout.NORTH);
    sidebar.add(centerPanel, BorderLayout.CENTER);
    sidebar.add(logoutPanel, BorderLayout.SOUTH);

    return sidebar;
}


    private JButton createSidebarButton(String text) {
        JButton button = new JButton(text);
        button.setMaximumSize(new Dimension(200, 40));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setFont(new Font("Arial", Font.PLAIN, 16));
        button.setFocusPainted(false);
        return button;
    }

    private void loadAllAccounts() {
        model.setRowCount(0);
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            Statement stmt = conn.createStatement();

            ResultSet rs1 = stmt.executeQuery("SELECT StudentID AS AccountID, UserID, StudentNumber AS Number FROM Student");
            while (rs1.next()) {
                model.addRow(new Object[]{"Student", rs1.getString("AccountID"), rs1.getString("UserID"), rs1.getString("Number")});
            }

            ResultSet rs2 = stmt.executeQuery("SELECT LibrarianID AS AccountID, UserID, EmployeeNumber AS Number FROM Librarian");
            while (rs2.next()) {
                model.addRow(new Object[]{"Librarian", rs2.getString("AccountID"), rs2.getString("UserID"), rs2.getString("Number")});
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Database error: " + e.getMessage());
        }
    }

    private void deleteSelectedAcc() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(frame, "Please select an account to delete.");
            return;
        }

        String type = model.getValueAt(selectedRow, 0).toString();
        String accountId = model.getValueAt(selectedRow, 1).toString();
        String userId = model.getValueAt(selectedRow, 2).toString();

        if (type.equals("Librarian") && Integer.parseInt(accountId) == librarianUserID) {
            JOptionPane.showMessageDialog(frame, "You cannot delete your own librarian account.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(frame,
                "Are you sure you want to delete this " + type + " account?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            conn.setAutoCommit(false);

            String deleteAccSql = "DELETE FROM " + (type.equals("Student") ? "Student" : "Librarian")
                    + " WHERE " + (type.equals("Student") ? "StudentID" : "LibrarianID") + " = ?";
            try (PreparedStatement ps = conn.prepareStatement(deleteAccSql)) {
                ps.setString(1, accountId);
                ps.executeUpdate();
            }

            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM User WHERE id = ?")) {
                ps.setString(1, userId);
                ps.executeUpdate();
            }

            conn.commit();
            JOptionPane.showMessageDialog(frame, type + " account deleted successfully.");
            loadAllAccounts();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Deletion failed: " + e.getMessage());
        }
    }
}
