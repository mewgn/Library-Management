import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.sql.*;

public class EditBookPage {
    private JFrame frame;
    private JTable table;
    private DefaultTableModel model;
    private String fullName;

    public EditBookPage(String fullName) {
        this.fullName = fullName;
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Edit Books");
        frame.setSize(1300, 800); // Widened window
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        frame.add(createSidebarPanel(), BorderLayout.WEST);
        frame.add(createMainPanel(), BorderLayout.CENTER);

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private JPanel createSidebarPanel() {
        JPanel sidebar = new JPanel();
        sidebar.setBackground(Color.DARK_GRAY);
        sidebar.setPreferredSize(new Dimension(250, frame.getHeight()));
        sidebar.setLayout(new BorderLayout());

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
        topPanel.setBackground(Color.DARK_GRAY);

        JLabel title = new JLabel("DASHBOARD", SwingConstants.CENTER);
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        topPanel.add(title);

        try {
            URL logoUrl = getClass().getResource("mapua_logo.png");
            if (logoUrl != null) {
                ImageIcon icon = new ImageIcon(logoUrl);
                Image scaled = icon.getImage().getScaledInstance(150, 100, Image.SCALE_SMOOTH);
                JLabel logo = new JLabel(new ImageIcon(scaled));
                logo.setAlignmentX(Component.CENTER_ALIGNMENT);
                JPanel logoPanel = new JPanel();
                logoPanel.setBackground(Color.DARK_GRAY);
                logoPanel.add(logo);
                topPanel.add(logoPanel);
            }
        } catch (Exception e) {
            System.err.println("Error loading logo.");
        }

        JPanel centerPanel = new JPanel();
        centerPanel.setBackground(Color.DARK_GRAY);
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(100, 20, 100, 20));

        JButton manageBooksBtn = createSidebarButton("Manage Books");
        JButton bookStatusBtn = createSidebarButton("Book Status");
        JButton manageAccountsBtn = createSidebarButton("Manage Accounts");

        centerPanel.add(manageBooksBtn);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        centerPanel.add(bookStatusBtn);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        centerPanel.add(manageAccountsBtn);

        manageBooksBtn.addActionListener(e -> {
            frame.dispose();
            LibrarianDashboard.showDashboard(fullName);
        });

        bookStatusBtn.addActionListener(e -> {
            frame.dispose();
            new BookStatusPage(fullName);
        });

        manageAccountsBtn.addActionListener(e -> {
            frame.dispose();
            new ManageAccount(fullName);
        });

        JPanel logoutPanel = new JPanel();
        logoutPanel.setBackground(Color.DARK_GRAY);
        logoutPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        logoutPanel.setLayout(new BoxLayout(logoutPanel, BoxLayout.Y_AXIS));

        JButton logoutBtn = new JButton("LOGOUT");
        logoutBtn.setFont(new Font("Arial", Font.BOLD, 16));
        logoutBtn.setMaximumSize(new Dimension(200, 40));
        logoutBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoutBtn.setBackground(Color.WHITE);
        logoutBtn.setFocusPainted(false);
        logoutBtn.addActionListener(e -> {
            frame.dispose();
            new Login_Page().setVisible(true);
        });

        logoutPanel.add(logoutBtn);

        sidebar.add(topPanel, BorderLayout.NORTH);
        sidebar.add(centerPanel, BorderLayout.CENTER);
        sidebar.add(logoutPanel, BorderLayout.SOUTH);

        return sidebar;
    }

    private JButton createSidebarButton(String text) {
        JButton button = new JButton(text);
        button.setMaximumSize(new Dimension(200, 40));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setFont(new Font("Arial", Font.PLAIN, 16));
        button.setFocusPainted(false);
        return button;
    }

    private JPanel createMainPanel() {
        JPanel contentPanel = new JPanel() {
            Image bg = new ImageIcon(getClass().getResource("mapua_bg.png")).getImage();
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(bg, 0, 0, getWidth(), getHeight(), this);
            }
        };
        contentPanel.setLayout(new BorderLayout());

        JLabel header = new JLabel("Edit books directly in the table and click 'Save Changes'", SwingConstants.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 20));
        header.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        contentPanel.add(header, BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{
                "ISBN", "Book Title", "Authors", "Category", "Publisher", "Publish Date", "Overview"
        }, 0) {
            public boolean isCellEditable(int row, int column) {
                return column != 0; // Make ISBN non-editable
            }
        };

        table = new JTable(model);
        table.setFont(new Font("Arial", Font.PLAIN, 14));
        table.setRowHeight(25);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS); // Fit table content
        loadBooks();

        JScrollPane scrollPane = new JScrollPane(table);
        contentPanel.add(scrollPane, BorderLayout.CENTER);

        JButton saveBtn = new JButton("Save Changes");
        saveBtn.setFont(new Font("Arial", Font.BOLD, 18)); // Larger font
        saveBtn.setPreferredSize(new Dimension(240, 50));  // Wider and taller
        saveBtn.addActionListener(e -> saveChanges());

        JButton backBtn = new JButton("Back to Dashboard");
        backBtn.setFont(new Font("Arial", Font.BOLD, 18)); // Larger font
        backBtn.setPreferredSize(new Dimension(220, 50));  // Wider and taller
        backBtn.addActionListener(e -> {
        frame.dispose();
        LibrarianDashboard.showDashboard(fullName);
});


        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false);
        buttonPanel.add(saveBtn);
        buttonPanel.add(backBtn);

        contentPanel.add(buttonPanel, BorderLayout.SOUTH);
        return contentPanel;
    }

    private void loadBooks() {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            String sql = "SELECT ISBN, BookName, Authors, CategoryName, Publisher, PublishedDate, Overview FROM LibraryMaterial";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            model.setRowCount(0);
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getString("ISBN"),
                        rs.getString("BookName"),
                        rs.getString("Authors"),
                        rs.getString("CategoryName"),
                        rs.getString("Publisher"),
                        rs.getString("PublishedDate"),
                        rs.getString("Overview")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Database error: " + e.getMessage());
        }
    }

    private void saveChanges() {
        int rows = model.getRowCount();
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            PreparedStatement stmt = conn.prepareStatement(
                    "UPDATE LibraryMaterial SET BookName=?, Authors=?, CategoryName=?, Publisher=?, PublishedDate=?, Overview=? WHERE ISBN=?"
            );

            for (int i = 0; i < rows; i++) {
                String isbn = model.getValueAt(i, 0).toString();
                stmt.setString(1, model.getValueAt(i, 1).toString());
                stmt.setString(2, model.getValueAt(i, 2).toString());
                stmt.setString(3, model.getValueAt(i, 3).toString());
                stmt.setString(4, model.getValueAt(i, 4).toString());
                stmt.setString(5, model.getValueAt(i, 5).toString());
                stmt.setString(6, model.getValueAt(i, 6).toString());
                stmt.setString(7, isbn);
                stmt.addBatch();
            }

            stmt.executeBatch();
            JOptionPane.showMessageDialog(frame, "All changes saved successfully.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Error saving changes: " + e.getMessage());
        }
    }
}
