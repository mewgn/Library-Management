import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class EditAccPage {
    private JFrame frame;
    private JTable table;
    private DefaultTableModel model;
    private JTextField nameField;
    private JPasswordField passwordField;
    private String fullName;
    private int librarianUserID;
    private JFrame dashboardFrame;

    public static void showDashboard(String fullName, JFrame dashboardFrame) {
        SwingUtilities.invokeLater(() -> {
            if (dashboardFrame != null) {
                dashboardFrame.setVisible(false);
            }
            new EditAccPage(fullName, dashboardFrame);
        });
    }

    public EditAccPage(String fullName, JFrame dashboardFrame) {
        this.fullName = fullName;
        this.dashboardFrame = dashboardFrame;

        if (dashboardFrame != null) {
            dashboardFrame.setVisible(false);
        }

        initialize();
    }

    private void initialize() {
        frame = new JFrame("Edit Accounts");
        frame.setSize(1200, 700);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        try {
            java.lang.reflect.Method sidebarMethod = ManageAccount.class.getDeclaredMethod("createSidebarPanel");
            sidebarMethod.setAccessible(true);
            JPanel sidebarPanel = (JPanel) sidebarMethod.invoke(new ManageAccount(fullName));
            sidebarPanel.setPreferredSize(new Dimension(250, frame.getHeight()));
            frame.add(sidebarPanel, BorderLayout.WEST);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        model = new DefaultTableModel(new String[]{"AccountType", "AccountID", "UserID", "Number"}, 0);
        table = new JTable(model);
        table.setRowHeight(25);
        loadAllAccounts();

        JScrollPane scrollPane = new JScrollPane(table);

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel nameLabel = new JLabel("Full Name:");
        nameLabel.setFont(new Font("Arial", Font.BOLD, 16));
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(nameLabel, gbc);

        nameField = new JTextField();
        nameField.setFont(new Font("Arial", Font.PLAIN, 16));
        nameField.setPreferredSize(new Dimension(300, 30));
        gbc.gridx = 1;
        gbc.gridy = 0;
        formPanel.add(nameField, gbc);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 16));
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(passwordLabel, gbc);

        passwordField = new JPasswordField();
        passwordField.setFont(new Font("Arial", Font.PLAIN, 16));
        passwordField.setPreferredSize(new Dimension(300, 30));
        gbc.gridx = 1;
        gbc.gridy = 1;
        formPanel.add(passwordField, gbc);

        JButton saveBtn = new JButton("Save Changes");
        saveBtn.setFont(new Font("Arial", Font.BOLD, 18));
        saveBtn.setPreferredSize(new Dimension(220, 45));
        saveBtn.setBackground(new Color(34, 139, 34));
        saveBtn.setForeground(Color.WHITE);
        saveBtn.putClientProperty("activeButton", saveBtn);
        saveBtn.addActionListener(e -> saveChanges());

        JButton backBtn = new JButton("Back to Dashboard");
        backBtn.setFont(new Font("Arial", Font.PLAIN, 18));
        backBtn.setPreferredSize(new Dimension(220, 45));
        backBtn.addActionListener(e -> {
            frame.dispose();
            if (dashboardFrame != null) {
            dashboardFrame.setVisible(true);
        }
    });

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;

        JPanel buttonHolder = new JPanel();
        buttonHolder.setOpaque(false);
        buttonHolder.add(saveBtn);
        buttonHolder.add(backBtn);
        formPanel.add(buttonHolder, gbc);

        JPanel centerPanel = new JPanel(new BorderLayout()) {
            Image bg = new ImageIcon(getClass().getResource("/mapua_bg.png")).getImage();

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(bg, 0, 0, getWidth(), getHeight(), this);
            }
        };
        centerPanel.setOpaque(false);
        centerPanel.add(scrollPane, BorderLayout.CENTER);
        centerPanel.add(formPanel, BorderLayout.SOUTH);

        frame.add(centerPanel, BorderLayout.CENTER);

        table.getSelectionModel().addListSelectionListener(e -> loadSelectedUserData());

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void loadAllAccounts() {
        model.setRowCount(0);
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            Statement stmt = conn.createStatement();

            ResultSet rs1 = stmt.executeQuery("SELECT StudentID AS AccountID, UserID, StudentNumber AS Number FROM Student");
            while (rs1.next()) {
                model.addRow(new Object[]{"Student", rs1.getString("AccountID"), rs1.getString("UserID"), rs1.getString("Number")});
            }

            ResultSet rs2 = stmt.executeQuery("SELECT LibrarianID AS AccountID, UserID, EmployeeNumber AS Number FROM Librarian");
            while (rs2.next()) {
                model.addRow(new Object[]{"Librarian", rs2.getString("AccountID"), rs2.getString("UserID"), rs2.getString("Number")});
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Database error: " + e.getMessage());
        }
    }

    private void loadSelectedUserData() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) return;

        String userId = model.getValueAt(selectedRow, 2).toString();

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            String query = "SELECT fullname, password FROM User WHERE id = ?";
            try (PreparedStatement ps = conn.prepareStatement(query)) {
                ps.setString(1, userId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    nameField.setText(rs.getString("fullname"));
                    passwordField.setText(rs.getString("password"));
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Error loading user data: " + e.getMessage());
        }
    }

    private void saveChanges() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(frame, "Please select an account first.");
            return;
        }

        String userId = model.getValueAt(selectedRow, 2).toString();
        String updatedName = nameField.getText().trim();
        String updatedPassword = new String(passwordField.getPassword()).trim();

        if (updatedName.isEmpty() || updatedPassword.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Name or Password cannot be empty.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                frame,
                "Are you sure you want to update this account's information?",
                "Confirm Update",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION) return;

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            String updateQuery = "UPDATE User SET fullname = ?, password = ? WHERE id = ?";
            try (PreparedStatement ps = conn.prepareStatement(updateQuery)) {
                ps.setString(1, updatedName);
                ps.setString(2, updatedPassword);
                ps.setString(3, userId);
                int rowsAffected = ps.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(frame, "Successfully updated account.");
                } else {
                    JOptionPane.showMessageDialog(frame, "Update failed.");
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Error saving changes: " + e.getMessage());
        }
    }
}
