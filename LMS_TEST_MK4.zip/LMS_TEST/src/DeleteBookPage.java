import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class DeleteBookPage {
    private JFrame frame;
    private JTable table;
    private DefaultTableModel model;
    private String fullName;
    private int librarianUserID;

    public DeleteBookPage(String fullName, int librarianUserID) {
        this.fullName = fullName;
        this.librarianUserID = librarianUserID;
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Delete Books");
        frame.setSize(1000, 600);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        JLabel header = new JLabel("Select a book and press Delete", SwingConstants.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 20));
        header.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        frame.add(header, BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"ISBN", "Book Title", "Authors", "Category", "Publisher", "Publish Date"}, 0);
        table = new JTable(model);
        table.setRowHeight(25);
        loadBooks();

        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        JButton deleteBtn = new JButton("Delete Selected Book");
        deleteBtn.setFont(new Font("Arial", Font.BOLD, 14));
        deleteBtn.setBackground(Color.RED);
        deleteBtn.setForeground(Color.WHITE);
        deleteBtn.addActionListener(e -> deleteSelectedBook());

        JButton backBtn = new JButton("Back to Dashboard");
        backBtn.setFont(new Font("Arial", Font.PLAIN, 14));
        backBtn.addActionListener(e -> {
            frame.dispose();
            LibrarianDashboard.showDashboard(fullName);
        });

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(new Color(220, 220, 220));
        bottomPanel.add(deleteBtn);
        bottomPanel.add(backBtn);
        frame.add(bottomPanel, BorderLayout.SOUTH);

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void loadBooks() {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            String sql = "SELECT ISBN, BookName, Authors, CategoryName, Publisher, PublishedDate FROM LibraryMaterial";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            model.setRowCount(0);

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getString("ISBN"),
                        rs.getString("BookName"),
                        rs.getString("Authors"),
                        rs.getString("CategoryName"),
                        rs.getString("Publisher"),
                        rs.getString("PublishedDate")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Database error: " + e.getMessage());
        }
    }

    private void deleteSelectedBook() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(frame, "Please select a book to delete.");
            return;
        }

        String isbn = model.getValueAt(row, 0).toString();
        int confirm = JOptionPane.showConfirmDialog(frame, "Are you sure you want to delete this book?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            PreparedStatement deleteStmt = conn.prepareStatement("DELETE FROM LibraryMaterial WHERE ISBN = ?");
            deleteStmt.setString(1, isbn);
            int rows = deleteStmt.executeUpdate();

            if (rows > 0) {
                JOptionPane.showMessageDialog(frame, "Book deleted successfully.");
                loadBooks();
            } else {
                JOptionPane.showMessageDialog(frame, "Book not found or could not be deleted.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Error: " + e.getMessage());
        }
    }
} 
