import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ReturnBooksPage {
    private JFrame frame;
    private JTable table;
    private DefaultTableModel tableModel;
    private String fullName;
    
     public static void showDashboard(String fullName) {
        SwingUtilities.invokeLater(() -> new ReturnBooksPage(fullName));
    }

    public ReturnBooksPage(String fullName) {
        this.fullName = fullName;
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Return Books");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(1100, 700);
        frame.setLayout(new BorderLayout());

        frame.add(createSidebarPanel(), BorderLayout.WEST);
        frame.add(createMainPanel(), BorderLayout.CENTER);

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private JPanel createSidebarPanel() {
        JPanel sidebar = new JPanel();
        sidebar.setBackground(Color.DARK_GRAY);
        sidebar.setPreferredSize(new Dimension(250, frame.getHeight()));
        sidebar.setLayout(new BorderLayout());

        JLabel title = new JLabel("DASHBOARD", SwingConstants.CENTER);
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));

        JPanel centerPanel = new JPanel();
        centerPanel.setBackground(Color.DARK_GRAY);
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));

        JButton manageBooksBtn = createSidebarButton("Manage Books");
        manageBooksBtn.addActionListener(e -> {
            frame.dispose();
            LibrarianDashboard.showDashboard(fullName);
        });

        JButton bookStatusBtn = createSidebarButton("Book Status");
        bookStatusBtn.addActionListener(e -> {
            frame.dispose();
            new BookStatusPage(fullName);
        });

        JButton manageAccountsBtn = createSidebarButton("Manage Accounts");

        centerPanel.add(Box.createVerticalGlue());
        centerPanel.add(manageBooksBtn);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        centerPanel.add(bookStatusBtn);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        centerPanel.add(manageAccountsBtn);
        centerPanel.add(Box.createVerticalGlue());

        JButton logoutBtn = new JButton("LOGOUT");
        logoutBtn.setFont(new Font("Arial", Font.BOLD, 16));
        logoutBtn.setMaximumSize(new Dimension(200, 40));
        logoutBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoutBtn.setBackground(Color.WHITE);
        logoutBtn.setFocusPainted(false);
        logoutBtn.addActionListener(e -> frame.dispose());

        JPanel logoutPanel = new JPanel();
        logoutPanel.setBackground(Color.DARK_GRAY);
        logoutPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        logoutPanel.setLayout(new BoxLayout(logoutPanel, BoxLayout.Y_AXIS));
        logoutPanel.add(logoutBtn);

        sidebar.add(title, BorderLayout.NORTH);
        sidebar.add(centerPanel, BorderLayout.CENTER);
        sidebar.add(logoutPanel, BorderLayout.SOUTH);

        return sidebar;
    }

    private JButton createSidebarButton(String text) {
        JButton button = new JButton(text);
        button.setMaximumSize(new Dimension(200, 40));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setFont(new Font("Arial", Font.PLAIN, 16));
        button.setFocusPainted(false);
        return button;
    }

    private JPanel createMainPanel() {
        JPanel panel = new JPanel();
        panel.setBackground(new Color(190, 186, 186));
        panel.setLayout(new BorderLayout());

        // Top: Search bar
        JPanel topPanel = new JPanel();
        topPanel.setBackground(new Color(190, 186, 186));
        topPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 30));

        JTextField searchField = new JTextField(40);
        JButton searchBtn = new JButton("Search");
        searchField.setPreferredSize(new Dimension(400, 30));
        searchBtn.setPreferredSize(new Dimension(100, 30));
        searchBtn.setFont(new Font("Arial", Font.BOLD, 14));

        topPanel.add(searchField);
        topPanel.add(searchBtn);

        // Middle: Tabs
        JPanel tabPanel = new JPanel();
        tabPanel.setBackground(new Color(190, 186, 186));
        tabPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 60, 10));

        JButton availableBtn = new JButton("Available Books");
        availableBtn.addActionListener(e -> {
            frame.dispose();
            BookStatusPage.showDashboard(fullName);
        });
        
        JButton borrowBtn = new JButton("Borrow Books");
        borrowBtn.addActionListener(e -> {
            frame.dispose();
            BorrowBooksPage.showDashboard(fullName);
        });
        JButton returnBtn = new JButton("Return Books");

        for (JButton btn : new JButton[]{availableBtn, borrowBtn, returnBtn}) {
            btn.setFont(new Font("Arial", Font.BOLD, 14));
            btn.setPreferredSize(new Dimension(140, 30));
            btn.setFocusPainted(false);
        }

        availableBtn.addActionListener(e -> {
            frame.dispose();
            new BookStatusPage(fullName);
        });

        borrowBtn.addActionListener(e -> {
            frame.dispose();
            new BorrowBooksPage(fullName);
        });

        tabPanel.add(availableBtn);
        tabPanel.add(borrowBtn);
        tabPanel.add(returnBtn);

        // Table
        String[] columnNames = {"Borrow ID", "Student ID", "Book Title", "Returned Date"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Bottom: Add Record button
        JButton addBtn = new JButton("ADD RECORD");
        addBtn.setFont(new Font("Arial", Font.BOLD, 18));
        addBtn.setPreferredSize(new Dimension(200, 50));
        addBtn.setFocusPainted(false);

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(new Color(190, 186, 186));
        bottomPanel.add(addBtn);

        // Compose layout
        JPanel topCombined = new JPanel(new BorderLayout());
        topCombined.setBackground(new Color(190, 186, 186));
        topCombined.add(topPanel, BorderLayout.NORTH);
        topCombined.add(tabPanel, BorderLayout.CENTER);

        panel.add(topCombined, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(bottomPanel, BorderLayout.SOUTH);

        loadReturnRecords();

        // Search bar function (optional filtering)
        searchBtn.addActionListener(e -> {
            String keyword = searchField.getText().trim();
            if (keyword.isEmpty()) {
                loadReturnRecords();
            }
        });

        return panel;
    }

    private void loadReturnRecords() {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {

            String query = "SELECT r.BorrowID, r.StudentID, l.BookName, r.ReturnedDate\n" + "    FROM ReturnRecord r\n" + "    LEFT JOIN LibraryMaterial l ON r.ISBN = l.ISBN\n";

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            tableModel.setRowCount(0); // Clear old data

            while (rs.next()) {
                Object[] row = {
                    rs.getInt("BorrowID"),
                    rs.getString("StudentID"),
                    rs.getString("BookName"),
                    rs.getDate("ReturnedDate")
                };
                tableModel.addRow(row);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Database error: " + e.getMessage());
        }
    }
}

