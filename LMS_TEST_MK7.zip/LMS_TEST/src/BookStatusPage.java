import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;

public class BookStatusPage {

    private JFrame frame;
    private JTable table;
    private DefaultTableModel tableModel;
    private JComboBox<String> studentDropdown;
    private JComboBox<String> isbnDropdown;
    private JTextField dateField;
    private JTextField searchField;
    private JPanel mainPanel;
    private String fullName;

    public static void showDashboard(String fullName) {
        SwingUtilities.invokeLater(() -> new BookStatusPage(fullName));
    }

    public BookStatusPage(String fullName) {
        this.fullName = fullName;
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Book Status");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(1100, 750);
        frame.setLayout(new BorderLayout());

        frame.add(createSidebarPanel(), BorderLayout.WEST);
        mainPanel = new JPanel(new BorderLayout());
        frame.add(mainPanel, BorderLayout.CENTER);

        showAvailableBooksPanel();

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private JPanel createSidebarPanel() {
        JPanel sidebar = new JPanel();
        sidebar.setBackground(Color.DARK_GRAY);
        sidebar.setPreferredSize(new Dimension(250, frame.getHeight()));
        sidebar.setLayout(new BorderLayout());

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
        topPanel.setBackground(Color.DARK_GRAY);

        JLabel title = new JLabel("DASHBOARD", SwingConstants.CENTER);
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        topPanel.add(title);

        try {
            URL logoUrl = getClass().getResource("mapua_logo.png");
            if (logoUrl != null) {
                ImageIcon originalIcon = new ImageIcon(logoUrl);
                Image scaledImage = originalIcon.getImage().getScaledInstance(150, 100, Image.SCALE_SMOOTH);
                JLabel logo = new JLabel(new ImageIcon(scaledImage));
                logo.setAlignmentX(Component.CENTER_ALIGNMENT);
                JPanel logoPanel = new JPanel();
                logoPanel.setBackground(Color.DARK_GRAY);
                logoPanel.add(logo);
                topPanel.add(logoPanel);
            }
        } catch (Exception e) {
            System.err.println("Error loading logo: " + e.getMessage());
        }

        JPanel centerPanel = new JPanel();
        centerPanel.setBackground(Color.DARK_GRAY);
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(100, 20, 100, 20));

        JButton manageBooksBtn = createSidebarButton("Manage Books");
        JButton bookStatusBtn = createSidebarButton("Book Status");
        JButton manageAccountsBtn = createSidebarButton("Manage Accounts");

        centerPanel.add(manageBooksBtn);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        centerPanel.add(bookStatusBtn);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        centerPanel.add(manageAccountsBtn);

        JPanel logoutPanel = new JPanel();
        logoutPanel.setBackground(Color.DARK_GRAY);
        logoutPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        logoutPanel.setLayout(new BoxLayout(logoutPanel, BoxLayout.Y_AXIS));

        JButton logoutBtn = new JButton("LOGOUT");
        logoutBtn.setFont(new Font("Arial", Font.BOLD, 16));
        logoutBtn.setMaximumSize(new Dimension(200, 40));
        logoutBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoutBtn.setBackground(Color.WHITE);
        logoutBtn.setFocusPainted(false);
        logoutBtn.addActionListener(e -> frame.dispose());

        logoutPanel.add(logoutBtn);

        sidebar.add(topPanel, BorderLayout.NORTH);
        sidebar.add(centerPanel, BorderLayout.CENTER);
        sidebar.add(logoutPanel, BorderLayout.SOUTH);

        manageBooksBtn.addActionListener(e -> {
            frame.dispose();
            LibrarianDashboard.showDashboard(fullName);
        });

        bookStatusBtn.addActionListener(e -> {
            frame.dispose();
            new BookStatusPage(fullName);
        });

        manageAccountsBtn.addActionListener(e -> JOptionPane.showMessageDialog(frame, "Manage Accounts clicked"));

        return sidebar;
    }

    private JButton createSidebarButton(String text) {
        JButton button = new JButton(text);
        button.setMaximumSize(new Dimension(200, 40));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setFont(new Font("Arial", Font.PLAIN, 16));
        button.setFocusPainted(false);
        return button;
    }

    private void showAvailableBooksPanel() {
        mainPanel.removeAll();

        JPanel tabPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 60, 10));
        tabPanel.setBackground(new Color(190, 186, 186));

        JButton availableBtn = new JButton("Available Books");
        JButton borrowBtn = new JButton("Borrow Books");
        JButton returnBtn = new JButton("Return Books");

        for (JButton btn : new JButton[]{availableBtn, borrowBtn, returnBtn}) {
            btn.setFont(new Font("Arial", Font.BOLD, 14));
            btn.setPreferredSize(new Dimension(140, 30));
            btn.setFocusPainted(false);
        }

        tabPanel.add(availableBtn);
        tabPanel.add(borrowBtn);
        tabPanel.add(returnBtn);
        returnBtn.addActionListener(e -> showReturnBooksPanel());

        availableBtn.setEnabled(false);

        borrowBtn.addActionListener(e -> showBorrowBooksPanel());

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 30));
        topPanel.setBackground(new Color(190, 186, 186));
        JTextField searchField = new JTextField("Search Book Title/Author", 40);
searchField.setForeground(Color.GRAY);
searchField.addFocusListener(new java.awt.event.FocusAdapter() {
    public void focusGained(java.awt.event.FocusEvent evt) {
        if (searchField.getText().equals("Search Book Title/Author")) {
            searchField.setText("");
            searchField.setForeground(Color.BLACK);
        }
    }

    public void focusLost(java.awt.event.FocusEvent evt) {
        if (searchField.getText().isEmpty()) {
            searchField.setText("Search Book Title/Author");
            searchField.setForeground(Color.GRAY);
        }
    }
});

        searchField.setPreferredSize(new Dimension(400, 30));
        topPanel.add(searchField);

        searchField.addActionListener(e -> {
            String keyword = searchField.getText().trim();
            loadAvailableBooks(keyword);
        });

        tableModel = new DefaultTableModel(new String[]{"ISBN", "Book Title", "Author", "Category", "Publisher", "Publish Date"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        JPanel combinedTop = new JPanel(new BorderLayout());
        combinedTop.setBackground(new Color(190, 186, 186));
        combinedTop.add(tabPanel, BorderLayout.NORTH);
        combinedTop.add(topPanel, BorderLayout.CENTER);

        mainPanel.add(combinedTop, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        loadAvailableBooks("");

        mainPanel.revalidate();
        mainPanel.repaint();
    }

    private void showBorrowBooksPanel() {
    mainPanel.removeAll();

    JPanel tabPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 60, 10));
    tabPanel.setBackground(new Color(190, 186, 186));

    JButton availableBtn = new JButton("Available Books");
    JButton borrowBtn = new JButton("Borrow Books");
    JButton returnBtn = new JButton("Return Books");

    for (JButton btn : new JButton[]{availableBtn, borrowBtn, returnBtn}) {
        btn.setFont(new Font("Arial", Font.BOLD, 14));
        btn.setPreferredSize(new Dimension(140, 30));
        btn.setFocusPainted(false);
    }

    borrowBtn.setEnabled(false);

    availableBtn.addActionListener(e -> showAvailableBooksPanel());
    returnBtn.addActionListener(e -> showReturnBooksPanel()); // ✅ JUST ADDED

    JPanel formPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 20));
    formPanel.setBackground(new Color(190, 186, 186));

    studentDropdown = new JComboBox<>();
    isbnDropdown = new JComboBox<>();
    dateField = new JTextField("YYYY-MM-DD", 10);

    dateField.setForeground(Color.GRAY);
    dateField.addFocusListener(new java.awt.event.FocusAdapter() {
        public void focusGained(java.awt.event.FocusEvent evt) {
            if (dateField.getText().equals("YYYY-MM-DD")) {
                dateField.setText("");
                dateField.setForeground(Color.BLACK);
            }
        }

        public void focusLost(java.awt.event.FocusEvent evt) {
            if (dateField.getText().isEmpty()) {
                dateField.setText("YYYY-MM-DD");
                dateField.setForeground(Color.GRAY);
            }
        }
    });

    JButton borrowButton = new JButton("Borrow Book");

    studentDropdown.setPreferredSize(new Dimension(150, 30));
    isbnDropdown.setPreferredSize(new Dimension(150, 30));
    dateField.setPreferredSize(new Dimension(150, 30));
    borrowButton.setPreferredSize(new Dimension(150, 30));

    formPanel.add(new JLabel("Student Number:"));
    formPanel.add(studentDropdown);
    formPanel.add(new JLabel("ISBN:"));
    formPanel.add(isbnDropdown);
    formPanel.add(new JLabel("Date:"));
    formPanel.add(dateField);
    formPanel.add(borrowButton);

    tabPanel.add(availableBtn);
    tabPanel.add(borrowBtn);
    tabPanel.add(returnBtn);

    borrowButton.addActionListener(e -> borrowBook());

    loadStudents();
    loadISBNs();

    mainPanel.add(tabPanel, BorderLayout.NORTH);
    mainPanel.add(formPanel, BorderLayout.CENTER);

    mainPanel.revalidate();
    mainPanel.repaint();
}


    private void loadAvailableBooks(String keyword) {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            String query = "SELECT ISBN, BookName, Authors, CategoryName, Publisher, PublishedDate FROM LibraryMaterial WHERE Status = 'Available'";
            if (!keyword.isEmpty()) {
                query += " AND (BookName LIKE '%" + keyword + "%' OR Authors LIKE '%" + keyword + "%')";
            }

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            tableModel.setRowCount(0);
            while (rs.next()) {
                Object[] row = {
                    rs.getString("ISBN"),
                    rs.getString("BookName"),
                    rs.getString("Authors"),
                    rs.getString("CategoryName"),
                    rs.getString("Publisher"),
                    rs.getDate("PublishedDate")
                };
                tableModel.addRow(row);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Database error: " + e.getMessage());
        }
    }

    private void loadStudents() {
        studentDropdown.removeAllItems();
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            PreparedStatement stmt = conn.prepareStatement("SELECT StudentNumber FROM Student");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                studentDropdown.addItem(rs.getString("StudentNumber"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Failed to load students: " + e.getMessage());
        }
    }

    private void loadISBNs() {
        isbnDropdown.removeAllItems();
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            PreparedStatement stmt = conn.prepareStatement("SELECT ISBN FROM LibraryMaterial WHERE Status = 'Available'");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                isbnDropdown.addItem(rs.getString("ISBN"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Failed to load ISBNs: " + e.getMessage());
        }
    }

    private void borrowBook() {
        String studentNumber = (String) studentDropdown.getSelectedItem();
        String isbn = (String) isbnDropdown.getSelectedItem();
        String date = dateField.getText().trim();

        if (studentNumber == null || isbn == null || date.isEmpty() || date.equals("YYYY-MM-DD")) {
            JOptionPane.showMessageDialog(frame, "Please fill all fields properly.");
            return;
        }

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            PreparedStatement studentStmt = conn.prepareStatement("SELECT StudentID FROM Student WHERE StudentNumber = ?");
            studentStmt.setString(1, studentNumber);
            ResultSet rs = studentStmt.executeQuery();

            if (!rs.next()) {
                JOptionPane.showMessageDialog(frame, "Student not found.");
                return;
            }

            int studentID = rs.getInt("StudentID");

            PreparedStatement borrowStmt = conn.prepareStatement(
                "INSERT INTO BorrowingList (StudentID, ISBN, BorrowedDate, ReturnStatus) VALUES (?, ?, ?, 'Borrowed')"
            );
            borrowStmt.setInt(1, studentID);
            borrowStmt.setString(2, isbn);
            borrowStmt.setDate(3, Date.valueOf(LocalDate.parse(date)));
            borrowStmt.executeUpdate();

            PreparedStatement updateStmt = conn.prepareStatement("UPDATE LibraryMaterial SET Status = 'Borrowed' WHERE ISBN = ?");
            updateStmt.setString(1, isbn);
            updateStmt.executeUpdate();

            JOptionPane.showMessageDialog(frame, "Book borrowed successfully!");
            showBorrowBooksPanel();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, "Error borrowing book: " + e.getMessage());
        }
    }
private void showReturnBooksPanel() {
    mainPanel.removeAll();

    JPanel tabPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 60, 10));
    tabPanel.setBackground(new Color(190, 186, 186));

    JButton availableBtn = new JButton("Available Books");
    JButton borrowBtn = new JButton("Borrow Books");
    JButton returnBtn = new JButton("Return Books");

    for (JButton btn : new JButton[]{availableBtn, borrowBtn, returnBtn}) {
        btn.setFont(new Font("Arial", Font.BOLD, 14));
        btn.setPreferredSize(new Dimension(140, 30));
        btn.setFocusPainted(false);
    }

    returnBtn.setEnabled(false);
    availableBtn.addActionListener(e -> showAvailableBooksPanel());
    borrowBtn.addActionListener(e -> showBorrowBooksPanel());

    tabPanel.add(availableBtn);
    tabPanel.add(borrowBtn);
    tabPanel.add(returnBtn);

    tableModel = new DefaultTableModel(new String[]{"BorrowID", "StudentNumber", "Book Title", "Borrowed Date", "Return Date"}, 0);
    table = new JTable(tableModel);
    JScrollPane scrollPane = new JScrollPane(table);

    JButton returnBookBtn = new JButton("Return Selected Book");
    returnBookBtn.setPreferredSize(new Dimension(200, 30));
    returnBookBtn.setFont(new Font("Arial", Font.BOLD, 14));
    returnBookBtn.addActionListener(e -> returnSelectedBook());

    JPanel bottomPanel = new JPanel();
    bottomPanel.setBackground(new Color(190, 186, 186));
    bottomPanel.add(returnBookBtn);

    mainPanel.add(tabPanel, BorderLayout.NORTH);
    mainPanel.add(scrollPane, BorderLayout.CENTER);
    mainPanel.add(bottomPanel, BorderLayout.SOUTH);

    loadBorrowedBooks();

    mainPanel.revalidate();
    mainPanel.repaint();
}

private void loadBorrowedBooks() {
    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
        String query = "SELECT b.BorrowID, s.StudentNumber, m.BookName, b.BorrowedDate, b.ActualReturnDate " +
                       "FROM BorrowingList b " +
                       "JOIN Student s ON b.StudentID = s.StudentID " +
                       "JOIN LibraryMaterial m ON b.ISBN = m.ISBN " +
                       "WHERE b.ReturnStatus = 'Borrowed'";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(query);

        tableModel.setRowCount(0);
        while (rs.next()) {
            Object[] row = {
                rs.getInt("BorrowID"),
                rs.getString("StudentNumber"),
                rs.getString("BookName"),
                rs.getDate("BorrowedDate"),
                rs.getDate("ActualReturnDate")
            };
            tableModel.addRow(row);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(frame, "Error loading borrowed books: " + e.getMessage());
    }
}

private void returnSelectedBook() {
    int selectedRow = table.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(frame, "Please select a row to return.");
        return;
    }

    int borrowID = (int) tableModel.getValueAt(selectedRow, 0);

    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
        PreparedStatement getISBNStmt = conn.prepareStatement("SELECT ISBN FROM BorrowingList WHERE BorrowID = ?");
        getISBNStmt.setInt(1, borrowID);
        ResultSet rs = getISBNStmt.executeQuery();
        if (!rs.next()) {
            JOptionPane.showMessageDialog(frame, "Invalid Borrow ID.");
            return;
        }
        String isbn = rs.getString("ISBN");

        PreparedStatement updateBorrowStmt = conn.prepareStatement(
            "UPDATE BorrowingList SET ReturnStatus = 'Returned', ActualReturnDate = CURRENT_DATE WHERE BorrowID = ?"
        );
        updateBorrowStmt.setInt(1, borrowID);
        updateBorrowStmt.executeUpdate();

        PreparedStatement updateBookStmt = conn.prepareStatement(
            "UPDATE LibraryMaterial SET Status = 'Available' WHERE ISBN = ?"
        );
        updateBookStmt.setString(1, isbn);
        updateBookStmt.executeUpdate();

        JOptionPane.showMessageDialog(frame, "Book returned successfully!");
        showReturnBooksPanel();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(frame, "Error returning book: " + e.getMessage());
    }
}
}
