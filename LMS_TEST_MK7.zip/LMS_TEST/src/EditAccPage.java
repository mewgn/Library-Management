import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class EditAccPage {
    private JFrame frame;
    private JTable table;
    private DefaultTableModel model;
    private JTextField nameField;
    private JPasswordField passwordField;
    private String fullName;
    private int librarianUserID;

    public static void showDashboard(String fullName) {
        SwingUtilities.invokeLater(() -> new EditAccPage(fullName));
    }

    public EditAccPage(String fullName) {
        this.fullName = fullName;
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Edit Accounts");
        frame.setSize(1000, 600);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        JLabel header = new JLabel("Select an account and edit full name or password", SwingConstants.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 20));
        header.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        frame.add(header, BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"AccountType", "AccountID", "UserID", "Number"}, 0);
        table = new JTable(model);
        table.setRowHeight(25);
        loadAllAccounts();

        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        table.getSelectionModel().addListSelectionListener(e -> loadSelectedUserData());

        // Editable fields
        JPanel editPanel = new JPanel();
        editPanel.setLayout(new GridLayout(2, 2, 10, 10));
        editPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        editPanel.add(new JLabel("Full Name:"));
        nameField = new JTextField();
        editPanel.add(nameField);

        editPanel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        editPanel.add(passwordField);

        // Buttons
        JButton saveBtn = new JButton("Save Changes");
        saveBtn.setBackground(new Color(34, 139, 34));
        saveBtn.setForeground(Color.WHITE);
        saveBtn.addActionListener(e -> saveChanges());

        JButton backBtn = new JButton("Back to Dashboard");
        backBtn.addActionListener(e -> {
            frame.dispose();
            ManageAccount.showDashboard(fullName);
        });

        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new BorderLayout());
        bottomPanel.add(editPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(saveBtn);
        buttonPanel.add(backBtn);
        bottomPanel.add(buttonPanel, BorderLayout.SOUTH);

        frame.add(bottomPanel, BorderLayout.SOUTH);

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void loadAllAccounts() {
        model.setRowCount(0);
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            Statement stmt = conn.createStatement();

            ResultSet rs1 = stmt.executeQuery("SELECT StudentID AS AccountID, UserID, StudentNumber AS Number FROM Student");
            while (rs1.next()) {
                model.addRow(new Object[]{"Student", rs1.getString("AccountID"), rs1.getString("UserID"), rs1.getString("Number")});
            }

            ResultSet rs2 = stmt.executeQuery("SELECT LibrarianID AS AccountID, UserID, EmployeeNumber AS Number FROM Librarian");
            while (rs2.next()) {
                model.addRow(new Object[]{"Librarian", rs2.getString("AccountID"), rs2.getString("UserID"), rs2.getString("Number")});
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Database error: " + e.getMessage());
        }
    }

    private void loadSelectedUserData() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) return;

        String userId = model.getValueAt(selectedRow, 2).toString();

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            String query = "SELECT fullname, password FROM User WHERE id = ?";
            try (PreparedStatement ps = conn.prepareStatement(query)) {
                ps.setString(1, userId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    nameField.setText(rs.getString("fullname"));
                    passwordField.setText(rs.getString("password"));
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Error loading user data: " + e.getMessage());
        }
    }

    private void saveChanges() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(frame, "Please select an account first.");
            return;
        }

        String userId = model.getValueAt(selectedRow, 2).toString();
        String updatedName = nameField.getText().trim();
        String updatedPassword = new String(passwordField.getPassword()).trim();

        if (updatedName.isEmpty() || updatedPassword.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Name or Password cannot be empty.");
            return;
        }

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            String updateQuery = "UPDATE User SET fullname = ?, password = ? WHERE id = ?";
            try (PreparedStatement ps = conn.prepareStatement(updateQuery)) {
                ps.setString(1, updatedName);
                ps.setString(2, updatedPassword);
                ps.setString(3, userId);
                int rowsAffected = ps.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(frame, "User information updated successfully.");
                } else {
                    JOptionPane.showMessageDialog(frame, "Update failed.");
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Error saving changes: " + e.getMessage());
        }
    }
}
