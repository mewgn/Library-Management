import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class BorrowHistory extends JFrame {
    private JTable historyTable;
    private DefaultTableModel tableModel;

    public BorrowHistory(String studentNumber) {
        setTitle("Borrow History");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create table model
        tableModel = new DefaultTableModel(new String[]{
            "Borrow ID", "Borrow Date", "Return Date", "Book Title", "ISBN"
        }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        // Create table and add to scroll pane
        historyTable = new JTable(tableModel);
        historyTable.setFont(new Font("Arial", Font.PLAIN, 16));
        historyTable.setRowHeight(24);
        JScrollPane scrollPane = new JScrollPane(historyTable);
        add(scrollPane, BorderLayout.CENTER);

        // Load data
        loadBorrowHistory(studentNumber);
    }

    private void loadBorrowHistory(String studentNumber) {
        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {

            String query = "SELECT b.BorrowID, b.BorrowedDate, b.ActualReturnDate, " +
                           "lm.BookName, b.ISBN " +
                           "FROM BorrowingList b " +
                           "JOIN LibraryMaterial lm ON b.ISBN = lm.ISBN " +
                           "WHERE b.StudentNumber = ?";

            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, studentNumber);
            ResultSet rs = stmt.executeQuery();

            tableModel.setRowCount(0); // Clear existing data

            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getInt("BorrowID"),
                    rs.getDate("BorrowedDate"),
                    rs.getDate("ActualReturnDate"),
                    rs.getString("BookName"),
                    rs.getString("ISBN")
                });
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage());
        }
    }

    public static void showHistory(String studentNumber) {
        EventQueue.invokeLater(() -> {
            BorrowHistory frame = new BorrowHistory(studentNumber);
            frame.setVisible(true);
        });
    }

    public static void main(String[] args) {
        showHistory("202312345"); // example student number for testing
    }
}
