import javax.swing.*;
import java.awt.*;

public class ManageAccount {

    private JFrame frame;
    private String fullName;

    public static void showDashboard(String fullName) {
        SwingUtilities.invokeLater(() -> new ManageAccount(fullName));
    }

    public ManageAccount(String fullName) {
        this.fullName = fullName;
        initialize();
    }

    public ManageAccount() {
        initialize(); // fallback default constructor (e.g. for main method)
    }

    private void initialize() {
        frame = new JFrame("Dashboard");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 600);
        frame.setLayout(new BorderLayout());

        // Left Panel (Sidebar)
        JPanel sidebar = new JPanel();
        sidebar.setBackground(Color.DARK_GRAY);
        sidebar.setPreferredSize(new Dimension(230, frame.getHeight()));
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));

        JLabel dashboardLabel = new JLabel("DASHBOARD");
        dashboardLabel.setForeground(Color.WHITE);
        dashboardLabel.setFont(new Font("Arial", Font.BOLD, 20));
        dashboardLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton manageBooksBtn = new JButton("Manage Books");
        JButton bookStatusBtn = new JButton("Book Status");
        JButton manageAccountsBtn = new JButton("Manage Accounts");
        JButton logoutBtn = new JButton("LOGOUT");

        Font btnFont = new Font("Arial", Font.BOLD, 14);
        for (JButton btn : new JButton[]{manageBooksBtn, bookStatusBtn, manageAccountsBtn, logoutBtn}) {
            btn.setMaximumSize(new Dimension(180, 35));
            btn.setFont(btnFont);
            btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        }
        logoutBtn.setBackground(Color.WHITE);

        sidebar.add(Box.createVerticalGlue());
        sidebar.add(dashboardLabel);
        sidebar.add(Box.createRigidArea(new Dimension(0, 30)));
        sidebar.add(manageBooksBtn);
        sidebar.add(Box.createRigidArea(new Dimension(0, 10)));
        sidebar.add(bookStatusBtn);
        sidebar.add(Box.createRigidArea(new Dimension(0, 10)));
        sidebar.add(manageAccountsBtn);
        sidebar.add(Box.createRigidArea(new Dimension(0, 40)));
        sidebar.add(logoutBtn);
        sidebar.add(Box.createVerticalGlue());
        
        manageBooksBtn.addActionListener(e -> {
            frame.dispose();
            LibrarianDashboard.showDashboard(fullName);
        });

        bookStatusBtn.addActionListener(e -> {
            frame.dispose();
            new BookStatusPage(fullName);
        });

        manageAccountsBtn.addActionListener(e -> {
            frame.dispose();
            new ManageAccount(fullName);
        });

        // Center Panel
        JPanel centerPanel = new JPanel();
        centerPanel.setBackground(Color.LIGHT_GRAY);
        centerPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 50, 200));

        JButton editAccountsBtn = new JButton("EDIT ACCOUNTS");
        JButton deleteAccountsBtn = new JButton("DELETE ACCOUNTS");

        for (JButton btn : new JButton[]{editAccountsBtn, deleteAccountsBtn}) {
            btn.setPreferredSize(new Dimension(300, 200));
            btn.setFont(new Font("Arial", Font.PLAIN, 20));
            btn.setBackground(Color.WHITE);
        }

        // Add Action Listeners
        editAccountsBtn.addActionListener(e -> {
            frame.dispose();
            new EditAccPage(fullName);
        });
        deleteAccountsBtn.addActionListener(e -> {
            frame.dispose();
            new DeleteAccPage(fullName);
        });


        centerPanel.add(editAccountsBtn);
        centerPanel.add(deleteAccountsBtn);

        // Add panels to frame
        frame.add(sidebar, BorderLayout.WEST);
        frame.add(centerPanel, BorderLayout.CENTER);

        frame.setLocationRelativeTo(null); // Center the window
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ManageAccount::new);
    }
}
