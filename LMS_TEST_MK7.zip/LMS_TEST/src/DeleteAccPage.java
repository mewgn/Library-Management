import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class DeleteAccPage {
    private JFrame frame;
    private JTable table;
    private DefaultTableModel model;
    private String fullName;
    private int librarianUserID;
    
    public static void showDashboard(String fullName) {
        SwingUtilities.invokeLater(() -> new DeleteAccPage(fullName));
    }

    public DeleteAccPage(String fullName) {
        this.fullName = fullName;
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Delete Accounts");
        frame.setSize(1000, 600);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        JLabel header = new JLabel("Select an account and press Delete", SwingConstants.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 20));
        header.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        frame.add(header, BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"AccountType", "AccountID", "UserID", "Number"}, 0);
        table = new JTable(model);
        table.setRowHeight(25);
        loadAllAccounts();

        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        JButton deleteBtn = new JButton("Delete Selected Account");
        deleteBtn.setFont(new Font("Arial", Font.BOLD, 14));
        deleteBtn.setBackground(Color.RED);
        deleteBtn.setForeground(Color.WHITE);
        deleteBtn.addActionListener(e -> deleteSelectedAcc());

        JButton backBtn = new JButton("Back to Dashboard");
        backBtn.setFont(new Font("Arial", Font.PLAIN, 14));
        backBtn.addActionListener(e -> {
            frame.dispose();
            ManageAccount.showDashboard(fullName);
        });

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(new Color(220, 220, 220));
        bottomPanel.add(deleteBtn);
        bottomPanel.add(backBtn);
        frame.add(bottomPanel, BorderLayout.SOUTH);

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void loadAllAccounts() {
        model.setRowCount(0); // clear table
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            Statement stmt = conn.createStatement();

            // Load Students
            ResultSet rs1 = stmt.executeQuery("SELECT StudentID AS AccountID, UserID, StudentNumber AS Number FROM Student");
            while (rs1.next()) {
                model.addRow(new Object[]{"Student", rs1.getString("AccountID"), rs1.getString("UserID"), rs1.getString("Number")});
            }

            // Load Librarians
            ResultSet rs2 = stmt.executeQuery("SELECT LibrarianID AS AccountID, UserID, EmployeeNumber AS Number FROM Librarian");
            while (rs2.next()) {
                model.addRow(new Object[]{"Librarian", rs2.getString("AccountID"), rs2.getString("UserID"), rs2.getString("Number")});
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Database error: " + e.getMessage());
        }
    }

    private void deleteSelectedAcc() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(frame, "Please select an account to delete.");
            return;
        }

        String type = model.getValueAt(selectedRow, 0).toString(); // "Student" or "Librarian"
        String accountId = model.getValueAt(selectedRow, 1).toString();
        String userId = model.getValueAt(selectedRow, 2).toString();

        // Prevent self-deletion
        if (type.equals("Librarian") && Integer.parseInt(accountId) == librarianUserID) {
            JOptionPane.showMessageDialog(frame, "You cannot delete your own librarian account.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(frame,
                "Are you sure you want to delete this " + type + " account?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            conn.setAutoCommit(false);

            // Delete from Student or Librarian table
            String deleteAccSql = "DELETE FROM " + (type.equals("Student") ? "Student" : "Librarian")
                    + " WHERE " + (type.equals("Student") ? "StudentID" : "LibrarianID") + " = ?";
            try (PreparedStatement ps = conn.prepareStatement(deleteAccSql)) {
                ps.setString(1, accountId);
                ps.executeUpdate();
            }

            // Delete from User table
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM User WHERE id = ?")) {
            ps.setString(1, userId);
            ps.executeUpdate();
            }

            conn.commit();
            JOptionPane.showMessageDialog(frame, type + " account deleted successfully.");
            loadAllAccounts();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Deletion failed: " + e.getMessage());
        }
    }
}
