import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ReturnBooksPage {

    private JFrame frame;
    private JTextField borrowIdField, studentIdField, isbnField, titleField, borrowDateField, returnDateField;

    public ReturnBooksPage() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Return Books");
        frame.setSize(600, 400);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        JPanel formPanel = new JPanel(new GridLayout(7, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        borrowIdField = new JTextField();
        studentIdField = new JTextField(); studentIdField.setEditable(false);
        isbnField = new JTextField(); isbnField.setEditable(false);
        titleField = new JTextField(); titleField.setEditable(false);
        borrowDateField = new JTextField(); borrowDateField.setEditable(false);
        returnDateField = new JTextField("YYYY-MM-DD");

        JButton fetchBtn = new JButton("Fetch");
        JButton returnBtn = new JButton("Return Book");

        formPanel.add(new JLabel("Borrow ID:"));
        formPanel.add(borrowIdField);
        formPanel.add(new JLabel(""));
        formPanel.add(fetchBtn);
        formPanel.add(new JLabel("Student ID:"));
        formPanel.add(studentIdField);
        formPanel.add(new JLabel("ISBN:"));
        formPanel.add(isbnField);
        formPanel.add(new JLabel("Book Title:"));
        formPanel.add(titleField);
        formPanel.add(new JLabel("Borrow Date:"));
        formPanel.add(borrowDateField);
        formPanel.add(new JLabel("Return Date:"));
        formPanel.add(returnDateField);
        formPanel.add(new JLabel(""));
        formPanel.add(returnBtn);

        frame.add(formPanel, BorderLayout.CENTER);
        frame.setVisible(true);

        fetchBtn.addActionListener(e -> fetchBorrowInfo());
        returnBtn.addActionListener(e -> returnBook());
    }

    private void fetchBorrowInfo() {
        String borrowId = borrowIdField.getText().trim();
        if (borrowId.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Enter a valid Borrow ID.");
            return;
        }

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            String query = "SELECT b.StudentID, b.ISBN, l.BookName, b.BorrowedDate FROM BorrowingList b JOIN LibraryMaterial l ON b.ISBN = l.ISBN WHERE b.BorrowID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, Integer.parseInt(borrowId));
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                studentIdField.setText(String.valueOf(rs.getInt("StudentID")));
                isbnField.setText(rs.getString("ISBN"));
                titleField.setText(rs.getString("BookName"));
                borrowDateField.setText(rs.getDate("BorrowedDate").toString());
            } else {
                JOptionPane.showMessageDialog(frame, "Borrow ID not found.");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(frame, "Database error: " + ex.getMessage());
        }
    }

    private void returnBook() {
        String borrowId = borrowIdField.getText().trim();
        String returnDate = returnDateField.getText().trim();
        String isbn = isbnField.getText().trim();

        if (borrowId.isEmpty() || returnDate.isEmpty() || returnDate.equals("YYYY-MM-DD")) {
            JOptionPane.showMessageDialog(frame, "Fill in all fields properly.");
            return;
        }

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            conn.setAutoCommit(false);

            PreparedStatement updateBorrow = conn.prepareStatement(
                "UPDATE BorrowingList SET ActualReturnDate = ?, ReturnStatus = 'Returned' WHERE BorrowID = ?"
            );
            updateBorrow.setDate(1, Date.valueOf(returnDate));
            updateBorrow.setInt(2, Integer.parseInt(borrowId));
            updateBorrow.executeUpdate();

            PreparedStatement updateBook = conn.prepareStatement(
                "UPDATE LibraryMaterial SET Status = 'Available' WHERE ISBN = ?"
            );
            updateBook.setString(1, isbn);
            updateBook.executeUpdate();

            conn.commit();
            JOptionPane.showMessageDialog(frame, "Book successfully returned.");
            clearFields();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage());
        }
    }

    private void clearFields() {
        borrowIdField.setText("");
        studentIdField.setText("");
        isbnField.setText("");
        titleField.setText("");
        borrowDateField.setText("");
        returnDateField.setText("YYYY-MM-DD");
    }

    public static void showPage() {
        SwingUtilities.invokeLater(ReturnBooksPage::new);
    }
}
