import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class EditBookPage {
    private JFrame frame;
    private JTable table;
    private DefaultTableModel model;
    private String fullName;

    public EditBookPage(String fullName) {
        this.fullName = fullName;
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Edit Books");
        frame.setSize(1000, 600);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        JLabel header = new JLabel("Edit books directly in the table and click 'Save Changes'", SwingConstants.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 20));
        header.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        frame.add(header, BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"ISBN", "Book Title", "Authors", "Category", "Publisher", "Publish Date", "Overview"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column != 0; // Make all columns editable except ISBN
            }
        };
        table = new JTable(model);
        table.setRowHeight(25);
        loadBooks();

        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        JButton saveBtn = new JButton("Save Changes");
        saveBtn.setPreferredSize(new Dimension(160, 40));
        saveBtn.addActionListener(e -> saveChanges());

        JButton backBtn = new JButton("Back to Dashboard");
        backBtn.setPreferredSize(new Dimension(160, 40));
        backBtn.addActionListener(e -> {
            frame.dispose();
            LibrarianDashboard.showDashboard(fullName);
        });

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(new Color(220, 220, 220));
        bottomPanel.add(saveBtn);
        bottomPanel.add(backBtn);
        frame.add(bottomPanel, BorderLayout.SOUTH);

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void loadBooks() {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            String sql = "SELECT ISBN, BookName, Authors, CategoryName, Publisher, PublishedDate, Overview FROM LibraryMaterial";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            model.setRowCount(0); // Clear old data

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getString("ISBN"),
                        rs.getString("BookName"),
                        rs.getString("Authors"),
                        rs.getString("CategoryName"),
                        rs.getString("Publisher"),
                        rs.getString("PublishedDate"),
                        rs.getString("Overview")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Database error: " + e.getMessage());
        }
    }

    private void saveChanges() {
        int rows = model.getRowCount();
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            PreparedStatement stmt = conn.prepareStatement(
                    "UPDATE LibraryMaterial SET BookName=?, Authors=?, CategoryName=?, Publisher=?, PublishedDate=?, Overview=? WHERE ISBN=?"
            );

            for (int i = 0; i < rows; i++) {
                String isbn = model.getValueAt(i, 0).toString();
                stmt.setString(1, model.getValueAt(i, 1).toString());
                stmt.setString(2, model.getValueAt(i, 2).toString());
                stmt.setString(3, model.getValueAt(i, 3).toString());
                stmt.setString(4, model.getValueAt(i, 4).toString());
                stmt.setString(5, model.getValueAt(i, 5).toString());
                stmt.setString(6, model.getValueAt(i, 6).toString());
                stmt.setString(7, isbn);
                stmt.addBatch();
            }

            stmt.executeBatch();
            JOptionPane.showMessageDialog(frame, "All changes saved successfully.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Error saving data: " + e.getMessage());
        }
    }
}
