import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.util.Vector;

public class User_Dashboard extends JFrame {
    private JTextField searchField;
    private JTable resultTable;
    private DefaultTableModel resultModel;
    private JScrollPane resultScroll;

    private JTextArea overviewText;
    private JPanel overviewPanel;
    private JButton backBtn;

    private JComboBox<String> studentDropdown;
    private JComboBox<String> isbnDropdown;
    private JButton borrowBookBtn;

    public static void showDashboard(String fullName) {
        SwingUtilities.invokeLater(() -> new User_Dashboard(fullName).setVisible(true));
    }

    public User_Dashboard(String fullName) {
        setTitle("User Dashboard");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1400, 800);
        setLocationRelativeTo(null);
        setLayout(null);

        // Background
        JLabel bg = new JLabel();
        bg.setBounds(0, 0, getWidth(), getHeight());
        try {
            URL img = getClass().getResource("dashboardbg_grey.png");
            if (img != null) bg.setIcon(new ImageIcon(img));
        } catch (Exception ignored) {}
        setContentPane(bg);
        bg.setLayout(null);

        // Sidebar
        JPanel side = new JPanel(null);
        side.setBounds(0, 0, 240, getHeight());
        side.setBackground(new Color(45, 43, 45));
        bg.add(side);

        JLabel dashLbl = new JLabel("DASHBOARD");
        dashLbl.setForeground(Color.WHITE);
        dashLbl.setFont(new Font("Arial", Font.BOLD, 20));
        dashLbl.setBounds(40, 10, 200, 30);
        side.add(dashLbl);

        try {
            URL logoUrl = getClass().getResource("mapua_logo.png");
            if (logoUrl != null) {
                JLabel logo = new JLabel(new ImageIcon(new ImageIcon(logoUrl)
                        .getImage().getScaledInstance(150, 100, Image.SCALE_SMOOTH)));
                logo.setBounds(45, 40, 150, 100);
                side.add(logo);
            }
        } catch (Exception ignored) {}

        Font btnFont = new Font("Arial", Font.BOLD, 18);
        int y = 160, h = 50, sp = 30;

        JButton btnSearch = new JButton("Search Books");
        btnSearch.setFont(btnFont);
        btnSearch.setBounds(20, y, 200, h);
        side.add(btnSearch);
        y += h + sp;

        JButton btnBorrowBooks = new JButton("Borrow Books");
        btnBorrowBooks.setFont(btnFont);
        btnBorrowBooks.setBounds(20, y, 200, h);
        side.add(btnBorrowBooks);
        y += h + sp;

        JButton btnLogout = new JButton("LOGOUT");
        btnLogout.setFont(btnFont);
        btnLogout.setBounds(20, getHeight() - 120, 200, 45);
        side.add(btnLogout);

        btnLogout.addActionListener(e -> {
            dispose();
            new Login_Page().setVisible(true);
        });

        // Main panel
        JPanel mainPanel = new JPanel(null);
        mainPanel.setBounds(260, 40, 1100, 700);
        bg.add(mainPanel);

        setupSearchComponents(mainPanel);
        setupOverviewComponents(mainPanel);
        setupBorrowComponents(mainPanel);

        btnSearch.addActionListener(e -> showSearchView());
        btnBorrowBooks.addActionListener(e -> showBorrowView());

        showSearchView();
    }

    private void setupSearchComponents(JPanel panel) {
        searchField = new JTextField("Search Book Title/Author");
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        searchField.setBounds(0, 0, 400, 40);
        searchField.setForeground(Color.GRAY);
        panel.add(searchField);
        searchField.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (searchField.getText().equals("Search Book Title/Author")) {
                    searchField.setText("");
                    searchField.setForeground(Color.BLACK);
                }
            }
            public void focusLost(FocusEvent e) {
                if (searchField.getText().isEmpty()) {
                    searchField.setText("Search Book Title/Author");
                    searchField.setForeground(Color.GRAY);
                }
            }
        });

        JButton searchBtn = new JButton("Search");
        searchBtn.setBounds(410, 0, 120, 40);
        searchBtn.setFont(new Font("Segoe UI", Font.BOLD, 18));
        panel.add(searchBtn);
        searchBtn.addActionListener(e -> loadAllBooks());

        resultModel = new DefaultTableModel(new String[]{"ISBN", "Title", "Author", "Category", "Publisher", "Pub Date"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        resultTable = new JTable(resultModel);
        resultScroll = new JScrollPane(resultTable);
        resultScroll.setBounds(0, 60, 1100, 520);
        panel.add(resultScroll);

        loadAllBooks();

        resultTable.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int r = resultTable.getSelectedRow();
                if (r >= 0) {
                    showOverview(resultModel.getValueAt(r, 0).toString());
                }
            }
        });
    }

    private void setupOverviewComponents(JPanel panel) {
        overviewPanel = new JPanel(new BorderLayout());
        overviewPanel.setBounds(0, 60, 1100, 520);
        overviewText = new JTextArea();
        overviewText.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        overviewText.setLineWrap(true);
        overviewText.setWrapStyleWord(true);
        overviewPanel.add(new JScrollPane(overviewText), BorderLayout.CENTER);

        backBtn = new JButton("Back to Results");
        backBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        overviewPanel.add(backBtn, BorderLayout.SOUTH);
        backBtn.addActionListener(e -> showSearchView());

        panel.add(overviewPanel);
    }

    private void setupBorrowComponents(JPanel panel) {
        studentDropdown = new JComboBox<>();
        studentDropdown.setBounds(0, 600, 200, 30);
        panel.add(studentDropdown);

        isbnDropdown = new JComboBox<>();
        isbnDropdown.setBounds(210, 600, 200, 30);
        panel.add(isbnDropdown);

        borrowBookBtn = new JButton("Borrow Book");
        borrowBookBtn.setBounds(420, 600, 200, 30);
        panel.add(borrowBookBtn);
        borrowBookBtn.addActionListener(e -> performBorrow());

        loadStudentNumbers();
        loadISBNs();
    }

    private void loadAllBooks() {
        resultModel.setRowCount(0);
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root","root")) {
            PreparedStatement ps = conn.prepareStatement("SELECT ISBN, BookName, Authors, CategoryName, Publisher, PublishedDate FROM LibraryMaterial");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                resultModel.addRow(new Vector<Object>() {{
                    add(rs.getString("ISBN"));
                    add(rs.getString("BookName"));
                    add(rs.getString("Authors"));
                    add(rs.getString("CategoryName"));
                    add(rs.getString("Publisher"));
                    add(rs.getDate("PublishedDate"));
                }});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading books: "+e.getMessage());
        }
    }

    private void showOverview(String isbn) {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root","root")) {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM LibraryMaterial WHERE ISBN=?");
            ps.setString(1, isbn);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                overviewText.setText(
                    "ISBN: " + rs.getString("ISBN") + "\n" +
                    "Title: " + rs.getString("BookName") + "\n" +
                    "Authors: " + rs.getString("Authors") + "\n" +
                    "Category: " + rs.getString("CategoryName") + "\n" +
                    "Publisher: " + rs.getString("Publisher") + "\n" +
                    "Published Date: " + rs.getDate("PublishedDate") + "\n\n" +
                    rs.getString("Overview")
                );
                resultScroll.setVisible(false);
                searchField.setVisible(false);
                overviewPanel.setVisible(true);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading overview: "+e.getMessage());
        }
    }

    private void showSearchView() {
        overviewPanel.setVisible(false);
        resultScroll.setVisible(true);
        searchField.setVisible(true);
        studentDropdown.setVisible(false);
        isbnDropdown.setVisible(false);
        borrowBookBtn.setVisible(false);
    }

    private void showBorrowView() {
        overviewPanel.setVisible(false);
        resultScroll.setVisible(true);
        searchField.setVisible(true);
        studentDropdown.setVisible(true);
        isbnDropdown.setVisible(true);
        borrowBookBtn.setVisible(true);
    }

    private void loadStudentNumbers() {
        studentDropdown.removeAllItems();
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            ResultSet rs = conn.createStatement().executeQuery("SELECT StudentNumber FROM Student");
            while (rs.next()) studentDropdown.addItem(rs.getString("StudentNumber"));
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading students: "+e.getMessage());
        }
    }

    private void loadISBNs() {
        isbnDropdown.removeAllItems();
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            ResultSet rs = conn.createStatement().executeQuery("SELECT ISBN FROM LibraryMaterial WHERE Status='Available'");
            while (rs.next()) isbnDropdown.addItem(rs.getString("ISBN"));
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading ISBNs: "+e.getMessage());
        }
    }

    private void performBorrow() {
        String sn = (String) studentDropdown.getSelectedItem();
        String isbn = (String) isbnDropdown.getSelectedItem();
        if (sn == null || isbn == null) {
            JOptionPane.showMessageDialog(this, "Select student and ISBN.");
            return;
        }

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root","root")) {
            PreparedStatement ps1 = conn.prepareStatement("SELECT StudentID FROM Student WHERE StudentNumber=?");
            ps1.setString(1, sn);
            ResultSet rs1 = ps1.executeQuery();
            if (!rs1.next()) {
                JOptionPane.showMessageDialog(this, "Student not found.");
                return;
            }
            int sid = rs1.getInt("StudentID");

            PreparedStatement ps2 = conn.prepareStatement(
                "INSERT INTO BorrowingList(StudentID, ISBN, BorrowedDate, ReturnStatus) " +
                "VALUES(?, ?, CURDATE(), 'Borrowed')"
            );
            ps2.setInt(1, sid);
            ps2.setString(2, isbn);
            ps2.executeUpdate();

            PreparedStatement ps3 = conn.prepareStatement("UPDATE LibraryMaterial SET Status='Borrowed' WHERE ISBN=?");
            ps3.setString(1, isbn);
            ps3.executeUpdate();

            JOptionPane.showMessageDialog(this, "Book borrowed!");
            loadAllBooks();
            loadISBNs();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error borrowing book: "+e.getMessage());
        }
    }

    public static void main(String[] args) {
        showDashboard("User");
    }
}
