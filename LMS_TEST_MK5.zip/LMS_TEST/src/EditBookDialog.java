import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class EditBookDialog extends JDialog {

    public EditBookDialog(JFrame parent, String isbn) {
        super(parent, "Edit Book", true);
        setSize(500, 600);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        // Input Fields
        JTextField titleField = new JTextField();
        JTextField authorField = new JTextField();
        JTextField categoryField = new JTextField();
        JTextField publisherField = new JTextField();
        JTextField dateField = new JTextField(); // yyyy-MM-dd
        JTextArea overviewArea = new JTextArea(4, 20);
        JScrollPane overviewScroll = new JScrollPane(overviewArea);

        // Load data from DB
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM LibraryMaterial WHERE ISBN = ?");
            stmt.setString(1, isbn);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                titleField.setText(rs.getString("BookName"));
                authorField.setText(rs.getString("Authors"));
                categoryField.setText(rs.getString("CategoryName"));
                publisherField.setText(rs.getString("Publisher"));
                dateField.setText(rs.getString("PublishedDate"));
                overviewArea.setText(rs.getString("Overview"));
            } else {
                JOptionPane.showMessageDialog(this, "Book not found.");
                dispose();
                return;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage());
            dispose();
            return;
        }

        // Layout panel
        JPanel formPanel = new JPanel(new GridLayout(0, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        formPanel.add(new JLabel("Book Title:")); formPanel.add(titleField);
        formPanel.add(new JLabel("Authors:")); formPanel.add(authorField);
        formPanel.add(new JLabel("Category:")); formPanel.add(categoryField);
        formPanel.add(new JLabel("Publisher:")); formPanel.add(publisherField);
        formPanel.add(new JLabel("Published Date:")); formPanel.add(dateField);
        formPanel.add(new JLabel("Overview:")); formPanel.add(overviewScroll);

        JScrollPane scrollPane = new JScrollPane(formPanel);
        add(scrollPane, BorderLayout.CENTER);

        // Save button
        JButton saveBtn = new JButton("Save");
        saveBtn.setFont(new Font("Arial", Font.BOLD, 14));
        saveBtn.addActionListener(e -> saveChanges(isbn, titleField, authorField, categoryField, publisherField, dateField, overviewArea));

        JPanel btnPanel = new JPanel();
        btnPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        btnPanel.add(saveBtn);
        add(btnPanel, BorderLayout.SOUTH);

        // ENTER key listener
        KeyAdapter saveOnEnter = new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    saveChanges(isbn, titleField, authorField, categoryField, publisherField, dateField, overviewArea);
                }
            }
        };

        titleField.addKeyListener(saveOnEnter);
        authorField.addKeyListener(saveOnEnter);
        categoryField.addKeyListener(saveOnEnter);
        publisherField.addKeyListener(saveOnEnter);
        dateField.addKeyListener(saveOnEnter);
        overviewArea.addKeyListener(saveOnEnter);

        setVisible(true);
    }

    private void saveChanges(String isbn, JTextField titleField, JTextField authorField, JTextField categoryField,
                             JTextField publisherField, JTextField dateField, JTextArea overviewArea) {

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to save these changes?",
                "Confirm Update",
                JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            PreparedStatement updateStmt = conn.prepareStatement(
                    "UPDATE LibraryMaterial SET BookName=?, Authors=?, CategoryName=?, Publisher=?, PublishedDate=?, Overview=? WHERE ISBN=?"
            );
            updateStmt.setString(1, titleField.getText().trim());
            updateStmt.setString(2, authorField.getText().trim());
            updateStmt.setString(3, categoryField.getText().trim());
            updateStmt.setString(4, publisherField.getText().trim());
            updateStmt.setString(5, dateField.getText().trim());
            updateStmt.setString(6, overviewArea.getText().trim());
            updateStmt.setString(7, isbn);

            int rows = updateStmt.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Book updated successfully!");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Update failed. No matching ISBN found.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error saving data: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
}
