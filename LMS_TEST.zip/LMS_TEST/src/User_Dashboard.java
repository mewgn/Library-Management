import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;

public class User_Dashboard extends JFrame {

    public static void showDashboard(String fullName) {
        EventQueue.invokeLater(() -> {
            try {
                User_Dashboard frame = new User_Dashboard(fullName);
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public User_Dashboard(String fullName) {
        setTitle("User Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1400, 800); // Made bigger
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel bg;
        URL imgUrl = getClass().getResource("dashboardbg_grey.png");
        if (imgUrl != null) {
            ImageIcon bgIcon = new ImageIcon(imgUrl);
            bg = new JLabel(bgIcon);
            bg.setBounds(0, 0, bgIcon.getIconWidth(), bgIcon.getIconHeight());
        } else {
            System.err.println("Background image not found!");
            bg = new JLabel();
            bg.setBounds(0, 0, getWidth(), getHeight());
        }

        setContentPane(bg);
        bg.setLayout(null);

        JPanel sidePanel = new JPanel();
        sidePanel.setBounds(0, 0, 240, getHeight()); // Wider panel
        sidePanel.setBackground(new Color(45, 43, 45));
        sidePanel.setLayout(null);
        bg.add(sidePanel);

        JLabel lblDashboard = new JLabel("DASHBOARD");
        lblDashboard.setForeground(Color.WHITE);
        lblDashboard.setFont(new Font("Arial", Font.BOLD, 20));
        lblDashboard.setBounds(30, 10, 180, 25);
        sidePanel.add(lblDashboard);

        try {
            JLabel logo = new JLabel(new ImageIcon(getClass().getResource("sidebg_grey.png")));
            logo.setBounds(45, 40, 150, 100);
            sidePanel.add(logo);
        } catch (NullPointerException e) {
            System.err.println("Dashboard logo not found!");
        }

        Font buttonFont = new Font("Arial", Font.BOLD, 18);
        int btnY = 160;
        int btnHeight = 50;
        int spacing = 30; // More spacing

        String[] options = {
            "Search Books",
            "View Books",
            "Borrow History"
        };

        for (String option : options) {
            JButton btn = new JButton(option);
            btn.setBounds(20, btnY, 200, btnHeight); // Wider buttons
            btn.setFont(buttonFont);
            sidePanel.add(btn);
            btnY += btnHeight + spacing;
        }

        JButton btnLogout = new JButton("LOGOUT");
        btnLogout.setBounds(20, getHeight() - 120, 200, 45);
        btnLogout.setFont(buttonFont);
        sidePanel.add(btnLogout);

        btnLogout.addActionListener(e -> {
            dispose();
            new Login_Page().setVisible(true);
        });
    }
}
