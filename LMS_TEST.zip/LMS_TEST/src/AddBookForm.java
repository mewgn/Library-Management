import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class AddBookForm {

    private JFrame frame;
    private Connection connection;
    private String fullName;
    
    public AddBookForm(String fullname) {
        this.fullName = fullname;
        initialize();
        connectToDatabase();
    }

    private void connectToDatabase() {
        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Establish connection to the database
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/librarysystem", "root", "root");
            System.out.println("Connected to database successfully!");
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(frame, "MySQL JDBC Driver not found!", "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Connection failed! Check database credentials.", "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void initialize() {
        frame = new JFrame("Add Book");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(1000, 700);
        frame.setLayout(new BorderLayout());

        frame.add(createSidebarPanel(), BorderLayout.WEST);
        frame.add(createFormPanel(), BorderLayout.CENTER);

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private JPanel createSidebarPanel() {
        JPanel sidebar = new JPanel();
        sidebar.setBackground(Color.DARK_GRAY);
        sidebar.setPreferredSize(new Dimension(250, frame.getHeight()));
        sidebar.setLayout(new BorderLayout());

        JLabel title = new JLabel("DASHBOARD", SwingConstants.CENTER);
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));

        JPanel centerPanel = new JPanel();
        centerPanel.setBackground(Color.DARK_GRAY);
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));

        JButton manageBooksBtn = createSidebarButton("Manage Books");
        manageBooksBtn.addActionListener(e -> {
            frame.dispose();
            LibrarianDashboard.showDashboard(fullName);
        });

        JButton bookStatusBtn = createSidebarButton("Book Status");
        JButton manageAccountsBtn = createSidebarButton("Manage Accounts");

        centerPanel.add(Box.createVerticalGlue());
        centerPanel.add(manageBooksBtn);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        centerPanel.add(bookStatusBtn);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        centerPanel.add(manageAccountsBtn);
        centerPanel.add(Box.createVerticalGlue());

        JButton logoutBtn = new JButton("LOGOUT");
        logoutBtn.setFont(new Font("Arial", Font.BOLD, 16));
        logoutBtn.setMaximumSize(new Dimension(200, 40));
        logoutBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoutBtn.setBackground(Color.WHITE);
        logoutBtn.setFocusPainted(false);
        logoutBtn.addActionListener(e -> {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            frame.dispose();
        });

        JPanel logoutPanel = new JPanel();
        logoutPanel.setBackground(Color.DARK_GRAY);
        logoutPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        logoutPanel.setLayout(new BoxLayout(logoutPanel, BoxLayout.Y_AXIS));
        logoutPanel.add(logoutBtn);

        sidebar.add(title, BorderLayout.NORTH);
        sidebar.add(centerPanel, BorderLayout.CENTER);
        sidebar.add(logoutPanel, BorderLayout.SOUTH);

        return sidebar;
    }

    private JButton createSidebarButton(String text) {
        JButton button = new JButton(text);
        button.setMaximumSize(new Dimension(200, 40));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setFont(new Font("Arial", Font.PLAIN, 16));
        button.setFocusPainted(false);
        return button;
    }

    private JPanel createFormPanel() {
        JPanel formPanel = new JPanel();
        formPanel.setBackground(new Color(190, 186, 186));
        formPanel.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        Font labelFont = new Font("Arial", Font.PLAIN, 16);
        Font inputFont = new Font("Arial", Font.PLAIN, 16);

        // Added Book Code field as it's the primary key in LibraryMaterial table
        String[] labels = {"Book Code:", "ISBN:", "Book Title:", "Author:", "Category:", "Publisher:", "Publish Date (YYYY-MM-DD):"};
        JTextField[] fields = new JTextField[labels.length];

        for (int i = 0; i < labels.length; i++) {
            gbc.gridx = 0;
            gbc.gridy = i;
            gbc.anchor = GridBagConstraints.EAST;

            JLabel label = new JLabel(labels[i]);
            label.setFont(labelFont);
            formPanel.add(label, gbc);

            gbc.gridx = 1;
            gbc.anchor = GridBagConstraints.WEST;

            fields[i] = new JTextField(20);
            fields[i].setFont(inputFont);
            formPanel.add(fields[i], gbc);
        }

        JButton addButton = new JButton("ADD BOOK");
        addButton.setFont(new Font("Arial", Font.BOLD, 18));
        addButton.setBackground(Color.WHITE);
        addButton.setFocusPainted(false);
        addButton.setPreferredSize(new Dimension(160, 40));
        addButton.addActionListener((ActionEvent e) -> {
            try {
                // Get values from text fields
                String bookCode = fields[0].getText().trim();
                String isbn = fields[1].getText().trim();
                String bookTitle = fields[2].getText().trim();
                String author = fields[3].getText().trim();
                String category = fields[4].getText().trim();
                String publisher = fields[5].getText().trim();
                String publishDateStr = fields[6].getText().trim();

                // Validate required fields
                if (bookCode.isEmpty() || bookTitle.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Book Code and Book Title are required!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Check if book code already exists
                if (bookExists(bookCode)) {
                    JOptionPane.showMessageDialog(frame, "Book with this code already exists!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Parse publish date
                Date publishDate = null;
                if (!publishDateStr.isEmpty()) {
                    try {
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                        java.util.Date date = sdf.parse(publishDateStr);
                        publishDate = new Date(date.getTime());
                    } catch (ParseException ex) {
                        JOptionPane.showMessageDialog(frame, "Invalid date format! Please use YYYY-MM-DD", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                // Get or create category
                int categoryId = getOrCreateCategory(category);

                // Insert into database
                String sql = "INSERT INTO LibraryMaterial (BookCode, BookName, Authors, PublishedDate, CategoryID, Publisher, ISBN) " +
                            "VALUES (?, ?, ?, ?, ?, ?, ?)";
                
                try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                    pstmt.setString(1, bookCode);
                    pstmt.setString(2, bookTitle);
                    pstmt.setString(3, author);
                    if (publishDate != null) {
                        pstmt.setDate(4, publishDate);
                    } else {
                        pstmt.setNull(4, Types.DATE);
                    }
                    pstmt.setInt(5, categoryId);
                    pstmt.setString(6, publisher);
                    pstmt.setString(7, isbn);

                    int affectedRows = pstmt.executeUpdate();
                    
                    if (affectedRows > 0) {
                        JOptionPane.showMessageDialog(frame, "Book added successfully!");
                        // Clear fields after successful addition
                        for (JTextField field : fields) {
                            field.setText("");
                        }
                    } else {
                        JOptionPane.showMessageDialog(frame, "Failed to add book!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(frame, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });

        gbc.gridx = 1;
        gbc.gridy = labels.length;
        gbc.anchor = GridBagConstraints.CENTER;
        formPanel.add(addButton, gbc);

        return formPanel;
    }

    private boolean bookExists(String bookCode) throws SQLException {
        String sql = "SELECT 1 FROM LibraryMaterial WHERE BookCode = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, bookCode);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        }
    }

    private int getOrCreateCategory(String categoryName) throws SQLException {
        if (categoryName == null || categoryName.trim().isEmpty()) {
            return 0; // or whatever default category ID you want
        }

        // First try to find existing category
        String findSql = "SELECT CategoryID FROM Category WHERE CategoryName = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(findSql)) {
            pstmt.setString(1, categoryName);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("CategoryID");
                }
            }
        }

        // If not found, create new category
        String insertSql = "INSERT INTO Category (CategoryName) VALUES (?)";
        try (PreparedStatement pstmt = connection.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, categoryName);
            pstmt.executeUpdate();
            try (ResultSet rs = pstmt.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }

        return 0; // default if something went wrong
    }

    @Override
    protected void finalize() throws Throwable {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        super.finalize();
    }
}

