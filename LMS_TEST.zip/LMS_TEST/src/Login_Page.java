import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Login_Page extends JFrame {

    private JTextField txtIdNumber;
    private JPasswordField txtPassword;
    private JButton btnLogin;
    private JButton btnRegister;
    private JCheckBox chkShowPassword;

    public Login_Page() {
        setTitle("Mapúa Library Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);

        ImageIcon bgIcon = new ImageIcon(getClass().getResource("login_bg.png"));
        JLabel bg = new JLabel(bgIcon);
        int width = bgIcon.getIconWidth();
        int height = bgIcon.getIconHeight();
        bg.setBounds(0, 0, width, height);
        setContentPane(bg);
        bg.setLayout(null);
        setSize(width, height);

        JLabel lblTitle = new JLabel("Login to Mapúa Library");
        lblTitle.setBounds(50, 30, 500, 40);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 35));
        lblTitle.setForeground(Color.WHITE);
        bg.add(lblTitle);

        JLabel lblUser = new JLabel("ID NUMBER");
        lblUser.setBounds(50, 120, 200, 25);
        lblUser.setForeground(Color.WHITE);
        lblUser.setFont(new Font("Arial", Font.BOLD, 20));
        bg.add(lblUser);

        txtIdNumber = new JTextField();
        txtIdNumber.setBounds(50, 160, 250, 35);
        txtIdNumber.setFont(new Font("Arial", Font.PLAIN, 16));
        bg.add(txtIdNumber);

        txtIdNumber.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c) || txtIdNumber.getText().length() >= 11) {
                    e.consume();
                }
            }
        });

        JLabel lblPass = new JLabel("PASSWORD");
        lblPass.setBounds(50, 230, 200, 25);
        lblPass.setForeground(Color.WHITE);
        lblPass.setFont(new Font("Arial", Font.BOLD, 20));
        bg.add(lblPass);

        txtPassword = new JPasswordField();
        txtPassword.setBounds(50, 265, 250, 35);
        txtPassword.setFont(new Font("Arial", Font.PLAIN, 16));
        bg.add(txtPassword);

        chkShowPassword = new JCheckBox("Show Password");
        chkShowPassword.setBounds(50, 305, 200, 25);
        chkShowPassword.setOpaque(false);
        chkShowPassword.setForeground(Color.WHITE);
        chkShowPassword.setFont(new Font("Arial", Font.PLAIN, 14));
        bg.add(chkShowPassword);

        chkShowPassword.addActionListener(e -> {
            if (chkShowPassword.isSelected()) {
                txtPassword.setEchoChar((char) 0);
            } else {
                txtPassword.setEchoChar('•');
            }
        });

        btnLogin = new JButton("LOGIN");
        btnLogin.setBounds(50, 340, 120, 40);
        btnLogin.setFont(new Font("Arial", Font.BOLD, 20));
        bg.add(btnLogin);

        btnLogin.addActionListener(e -> {
            String id = txtIdNumber.getText();
            String password = new String(txtPassword.getPassword());

            if (id.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Enter Valid ID Number/Password");
                return;
            }

            String fullName = checkLogin(id, password);
            if (fullName != null) {
                JOptionPane.showMessageDialog(this, "Login successful!");
                User_Dashboard.showDashboard(fullName);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid ID number or password.");
            }

            txtIdNumber.setText("");
            txtPassword.setText("");
            chkShowPassword.setSelected(false);
            txtPassword.setEchoChar('•');
        });

        btnRegister = new JButton("REGISTER");
        btnRegister.setBounds(180, 340, 140, 40);
        btnRegister.setFont(new Font("Arial", Font.BOLD, 20));
        bg.add(btnRegister);

        btnRegister.addActionListener(e -> {
            new Register_Page().setVisible(true);
        });
    }

    private String checkLogin(String idNumber, String password) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/librarysystem", "root", "root");

            String studentQuery = "SELECT u.fullname FROM User u JOIN Student s ON u.id = s.UserID WHERE s.StudentNumber = ? AND u.password = ? AND u.role = 'Student'";
            PreparedStatement stmt1 = conn.prepareStatement(studentQuery);
            stmt1.setString(1, idNumber);
            stmt1.setString(2, password);
            ResultSet rs1 = stmt1.executeQuery();
            if (rs1.next()) {
                return rs1.getString("fullname");
            }

            String librarianQuery = "SELECT u.fullname FROM User u JOIN Librarian l ON u.id = l.UserID WHERE l.EmployeeNumber = ? AND u.password = ? AND u.role = 'Librarian'";
            PreparedStatement stmt2 = conn.prepareStatement(librarianQuery);
            stmt2.setString(1, idNumber);
            stmt2.setString(2, password);
            ResultSet rs2 = stmt2.executeQuery();
            if (rs2.next()) {
                return rs2.getString("fullname");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage());
        }
        return null;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Login_Page().setVisible(true));
    }
}
