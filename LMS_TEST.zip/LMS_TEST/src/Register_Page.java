import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Register_Page extends JFrame {

    private JTextField txtFullName, txtIdNumber;
    private JPasswordField txtPassword, txtConfirmPassword;
    private JComboBox<String> cmbRole;
    private JButton btnRegister;

    public Register_Page() {
        setTitle("Register New User");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);

        ImageIcon bgIcon = new ImageIcon(getClass().getResource("login_bg.png"));
        JLabel bg = new JLabel(bgIcon);
        int width = bgIcon.getIconWidth();
        int height = bgIcon.getIconHeight();
        bg.setBounds(0, 0, width, height);

        setContentPane(bg);
        bg.setLayout(null);
        setSize(width, height);

        Font labelFont = new Font("Arial", Font.BOLD, 18);
        Font inputFont = new Font("Arial", Font.PLAIN, 16);

        int centerX = width / 2 - 200;
        int y = 80;
        int gap = 40;

        JLabel lblTitle = new JLabel("Register");
        lblTitle.setBounds(centerX + 100, 20, 200, 40);
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 28));
        bg.add(lblTitle);

        JLabel lblFullName = new JLabel("Full Name:");
        lblFullName.setBounds(centerX, y, 150, 25);
        lblFullName.setForeground(Color.WHITE);
        lblFullName.setFont(labelFont);
        bg.add(lblFullName);

        txtFullName = new JTextField();
        txtFullName.setBounds(centerX + 150, y, 250, 30);
        txtFullName.setFont(inputFont);
        bg.add(txtFullName);

        y += gap;
        JLabel lblRole = new JLabel("Role:");
        lblRole.setBounds(centerX, y, 150, 25);
        lblRole.setForeground(Color.WHITE);
        lblRole.setFont(labelFont);
        bg.add(lblRole);

        cmbRole = new JComboBox<>(new String[]{"Student", "Librarian"});
        cmbRole.setBounds(centerX + 150, y, 250, 30);
        cmbRole.setFont(inputFont);
        bg.add(cmbRole);

        y += gap;
        JLabel lblIdNumber = new JLabel("ID Number:");
        lblIdNumber.setBounds(centerX, y, 150, 25);
        lblIdNumber.setForeground(Color.WHITE);
        lblIdNumber.setFont(labelFont);
        bg.add(lblIdNumber);

        txtIdNumber = new JTextField();
        txtIdNumber.setBounds(centerX + 150, y, 250, 30);
        txtIdNumber.setFont(inputFont);
        bg.add(txtIdNumber);

        y += gap;
        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setBounds(centerX, y, 150, 25);
        lblPassword.setForeground(Color.WHITE);
        lblPassword.setFont(labelFont);
        bg.add(lblPassword);

        txtPassword = new JPasswordField();
        txtPassword.setBounds(centerX + 150, y, 250, 30);
        txtPassword.setFont(inputFont);
        bg.add(txtPassword);

        y += gap;
        JLabel lblConfirmPassword = new JLabel("Confirm Password:");
        lblConfirmPassword.setBounds(centerX, y, 180, 25);
        lblConfirmPassword.setForeground(Color.WHITE);
        lblConfirmPassword.setFont(labelFont);
        bg.add(lblConfirmPassword);

        txtConfirmPassword = new JPasswordField();
        txtConfirmPassword.setBounds(centerX + 150, y, 250, 30);
        txtConfirmPassword.setFont(inputFont);
        bg.add(txtConfirmPassword);

        y += gap + 10;
        btnRegister = new JButton("Register");
        btnRegister.setBounds(centerX + 150, y, 130, 40);
        btnRegister.setFont(new Font("Arial", Font.BOLD, 18));
        bg.add(btnRegister);

        btnRegister.addActionListener(e -> registerUser());
    }

    private void registerUser() {
        String fullName = txtFullName.getText();
        String idNumber = txtIdNumber.getText();
        String password = new String(txtPassword.getPassword());
        String confirm = new String(txtConfirmPassword.getPassword());
        String role = (String) cmbRole.getSelectedItem();

        if (!password.equals(confirm)) {
            JOptionPane.showMessageDialog(this, "Passwords do not match.");
            return;
        }

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/librarysystem", "root", "root");

            String insertUser = "INSERT INTO User (fullname, password, role) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(insertUser, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, fullName);
            stmt.setString(2, password);
            stmt.setString(3, role);
            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            int userId = 0;
            if (rs.next()) userId = rs.getInt(1);

            if (role.equals("Student")) {
                String insertStudent = "INSERT INTO Student (UserID, StudentNumber) VALUES (?, ?)";
                PreparedStatement stmt2 = conn.prepareStatement(insertStudent);
                stmt2.setInt(1, userId);
                stmt2.setString(2, idNumber);
                stmt2.executeUpdate();
            } else if (role.equals("Librarian")) {
                String insertLibrarian = "INSERT INTO Librarian (UserID, EmployeeNumber) VALUES (?, ?)";
                PreparedStatement stmt3 = conn.prepareStatement(insertLibrarian);
                stmt3.setInt(1, userId);
                stmt3.setString(2, idNumber);
                stmt3.executeUpdate();
            }

            JOptionPane.showMessageDialog(this, "Registration successful!");
            dispose();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage());
        }
    }
}
