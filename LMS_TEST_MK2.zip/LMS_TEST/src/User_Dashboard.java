import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.sql.*;

public class User_Dashboard extends JFrame {

    private JTextField searchField;
    private JTable resultTable;
    private DefaultTableModel tableModel;
    private JScrollPane scrollPane;
    private JButton searchBtn;

    public static void showDashboard(String fullName) {
        EventQueue.invokeLater(() -> {
            try {
                User_Dashboard frame = new User_Dashboard(fullName);
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public User_Dashboard(String fullName) {
        setTitle("User Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1400, 800);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel bg;
        URL imgUrl = getClass().getResource("dashboardbg_grey.png");
        if (imgUrl != null) {
            ImageIcon bgIcon = new ImageIcon(imgUrl);
            bg = new JLabel(bgIcon);
            bg.setBounds(0, 0, bgIcon.getIconWidth(), bgIcon.getIconHeight());
        } else {
            System.err.println("Background image not found!");
            bg = new JLabel();
            bg.setBounds(0, 0, getWidth(), getHeight());
        }

        setContentPane(bg);
        bg.setLayout(null);

        JPanel sidePanel = new JPanel();
        sidePanel.setBounds(0, 0, 240, getHeight());
        sidePanel.setBackground(new Color(45, 43, 45));
        sidePanel.setLayout(null);
        bg.add(sidePanel);

        JLabel lblDashboard = new JLabel("DASHBOARD");
        lblDashboard.setForeground(Color.WHITE);
        lblDashboard.setFont(new Font("Arial", Font.BOLD, 20));
        lblDashboard.setBounds(40, 10, 200, 30);
        sidePanel.add(lblDashboard);

        try {
            URL logoUrl = getClass().getResource("mapua_logo.png");
            if (logoUrl != null) {
                ImageIcon originalIcon = new ImageIcon(logoUrl);
                Image scaledImage = originalIcon.getImage().getScaledInstance(150, 100, Image.SCALE_SMOOTH);
                JLabel logo = new JLabel(new ImageIcon(scaledImage));
                logo.setBounds(45, 40, 150, 100);
                sidePanel.add(logo);
            } else {
                System.err.println("Dashboard logo not found!");
            }
        } catch (Exception e) {
            System.err.println("Error loading logo: " + e.getMessage());
        }

        Font buttonFont = new Font("Arial", Font.BOLD, 18);
        int btnY = 160;
        int btnHeight = 50;
        int spacing = 30;

        JButton btnSearchBooks = new JButton("Search Books");
        btnSearchBooks.setBounds(20, btnY, 200, btnHeight);
        btnSearchBooks.setFont(buttonFont);
        sidePanel.add(btnSearchBooks);
        btnY += btnHeight + spacing;

        JButton btnViewBooks = new JButton("View Books");
        btnViewBooks.setBounds(20, btnY, 200, btnHeight);
        btnViewBooks.setFont(buttonFont);
        sidePanel.add(btnViewBooks);
        btnY += btnHeight + spacing;

        JButton btnBorrowHistory = new JButton("Borrow History");
        btnBorrowHistory.setBounds(20, btnY, 200, btnHeight);
        btnBorrowHistory.setFont(buttonFont);
        sidePanel.add(btnBorrowHistory);

        JButton btnLogout = new JButton("LOGOUT");
        btnLogout.setBounds(20, getHeight() - 120, 200, 45);
        btnLogout.setFont(buttonFont);
        sidePanel.add(btnLogout);

        btnLogout.addActionListener(e -> {
            dispose();
            new Login_Page().setVisible(true);
        });

        searchField = new JTextField("Search Book Title/Author");
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        searchField.setBounds(300, 40, 400, 40);
        searchField.setForeground(Color.GRAY);
        searchField.setVisible(false);

        searchField.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (searchField.getText().equals("Search Book Title/Author")) {
                    searchField.setText("");
                    searchField.setForeground(Color.BLACK);
                }
            }

            public void focusLost(FocusEvent e) {
                if (searchField.getText().isEmpty()) {
                    searchField.setText("Search Book Title/Author");
                    searchField.setForeground(Color.GRAY);
                }
            }
        });
        bg.add(searchField);

        searchBtn = new JButton("Search");
        searchBtn.setFont(new Font("Segoe UI", Font.BOLD, 18));
        searchBtn.setBounds(720, 40, 120, 40);
        searchBtn.setVisible(false);
        bg.add(searchBtn);

        tableModel = new DefaultTableModel(
            new String[]{"ISBN", "Book Title", "Author", "Category", "Publisher", "Publish Date"}, 0
        ) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        resultTable = new JTable(tableModel);
        resultTable.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        resultTable.setRowHeight(25);

        scrollPane = new JScrollPane(resultTable);
        scrollPane.setBounds(260, 100, 1100, 550);
        scrollPane.setVisible(false);
        bg.add(scrollPane);

        searchBtn.addActionListener(e -> searchBooks());

        btnSearchBooks.addActionListener(e -> {
            searchField.setVisible(true);
            searchBtn.setVisible(true);
            scrollPane.setVisible(true);
        });

        btnViewBooks.addActionListener(e -> {
            searchField.setVisible(false);
            searchBtn.setVisible(false);
            scrollPane.setVisible(false);
        });

        btnBorrowHistory.addActionListener(e -> {
            searchField.setVisible(false);
            searchBtn.setVisible(false);
            scrollPane.setVisible(false);
        });
    }

    private void searchBooks() {
        String keyword = searchField.getText().trim();
        if (keyword.isEmpty() || keyword.equals("Search Book Title/Author")) {
            JOptionPane.showMessageDialog(this, "Please enter a title or author.");
            return;
        }

        tableModel.setRowCount(0);

        try {
            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/librarysystem", "root", "root"
            );

            String query = "SELECT lm.ISBN, lm.BookName, lm.Authors, c.CategoryName, lm.Publisher, lm.PublishedDate " +
                           "FROM LibraryMaterial lm " +
                           "LEFT JOIN Category c ON lm.CategoryID = c.CategoryID " +
                           "WHERE lm.BookName LIKE ? OR lm.Authors LIKE ?";

            PreparedStatement stmt = conn.prepareStatement(query);
            String wildcard = "%" + keyword + "%";
            stmt.setString(1, wildcard);
            stmt.setString(2, wildcard);

            ResultSet rs = stmt.executeQuery();
            boolean found = false;
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getString("ISBN"),
                    rs.getString("BookName"),
                    rs.getString("Authors"),
                    rs.getString("CategoryName"),
                    rs.getString("Publisher"),
                    rs.getDate("PublishedDate")
                });
                found = true;
            }

            if (!found) {
                JOptionPane.showMessageDialog(this, "Please Input a Valid Book Title/Author");
            }

            conn.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new User_Dashboard("User").setVisible(true));
    }
}
