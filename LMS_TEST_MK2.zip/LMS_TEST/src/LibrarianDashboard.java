import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class LibrarianDashboard {
    private JFrame frame;
    private String fullName;

    public static void showDashboard(String fullName) {
        SwingUtilities.invokeLater(() -> new LibrarianDashboard(fullName));
    }

    private LibrarianDashboard(String fullName) {
        this.fullName = fullName;
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Library Management System - Librarian");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 700);
        frame.setLayout(new BorderLayout());

        frame.add(createSidebarPanel(), BorderLayout.WEST);
        frame.add(createMainPanel(), BorderLayout.CENTER);

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private JPanel createSidebarPanel() {
        JPanel sidebar = new JPanel();
        sidebar.setBackground(Color.DARK_GRAY);
        sidebar.setPreferredSize(new Dimension(250, frame.getHeight()));
        sidebar.setLayout(new BorderLayout());

        JLabel title = new JLabel("DASHBOARD", SwingConstants.CENTER);
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));

        JPanel centerPanel = new JPanel();
        centerPanel.setBackground(Color.DARK_GRAY);
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));

        JButton manageBooksBtn = createSidebarButton("Manage Books");
        JButton bookStatusBtn = createSidebarButton("Book Status");
        JButton manageAccountsBtn = createSidebarButton("Manage Accounts");

        centerPanel.add(Box.createVerticalGlue());
        centerPanel.add(manageBooksBtn);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        centerPanel.add(bookStatusBtn);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        centerPanel.add(manageAccountsBtn);
        centerPanel.add(Box.createVerticalGlue());

        JButton logoutBtn = new JButton("LOGOUT");
        logoutBtn.setFont(new Font("Arial", Font.BOLD, 16));
        logoutBtn.setMaximumSize(new Dimension(200, 40));
        logoutBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoutBtn.setBackground(Color.WHITE);
        logoutBtn.setFocusPainted(false);
        logoutBtn.addActionListener(this::handleLogout);

        JPanel logoutPanel = new JPanel();
        logoutPanel.setBackground(Color.DARK_GRAY);
        logoutPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        logoutPanel.setLayout(new BoxLayout(logoutPanel, BoxLayout.Y_AXIS));
        logoutPanel.add(logoutBtn);

        sidebar.add(title, BorderLayout.NORTH);
        sidebar.add(centerPanel, BorderLayout.CENTER);
        sidebar.add(logoutPanel, BorderLayout.SOUTH);

        // Action listeners
        manageBooksBtn.addActionListener(e -> {
            frame.dispose();
            LibrarianDashboard.showDashboard(fullName); // refresh
        });
        bookStatusBtn.addActionListener(e -> showMessage("Book Status clicked"));
        manageAccountsBtn.addActionListener(e -> showMessage("Manage Accounts clicked"));

        return sidebar;
    }

    private JButton createSidebarButton(String text) {
        JButton button = new JButton(text);
        button.setMaximumSize(new Dimension(200, 40));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setFont(new Font("Arial", Font.PLAIN, 16));
        button.setFocusPainted(false);
        return button;
    }

    private JPanel createMainPanel() {
        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(new Color(190, 186, 186));
        mainPanel.setLayout(new GridBagLayout());

        JPanel cardPanel = new JPanel();
        cardPanel.setBackground(new Color(190, 186, 186));
        cardPanel.setLayout(new GridLayout(1, 3, 40, 0));

        JButton addBookBtn = createCardButton("ADD BOOKS");
        JButton editBookBtn = createCardButton("EDIT BOOKS");
        JButton deleteBookBtn = createCardButton("DELETE BOOKS");

        addBookBtn.addActionListener(e -> new AddBookForm(fullName));
        editBookBtn.addActionListener(e -> showMessage("Edit Books clicked"));
        deleteBookBtn.addActionListener(e -> showMessage("Delete Books clicked"));

        cardPanel.add(addBookBtn);
        cardPanel.add(editBookBtn);
        cardPanel.add(deleteBookBtn);

        mainPanel.add(cardPanel);

        return mainPanel;
    }

    private JButton createCardButton(String text) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(200, 200));
        button.setFont(new Font("Arial", Font.BOLD, 18));
        button.setBackground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }

    private void handleLogout(ActionEvent e) {
        int confirm = JOptionPane.showConfirmDialog(frame,
                "Are you sure you want to logout?", "Logout",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            frame.dispose(); // ✅ close dashboard
            SwingUtilities.invokeLater(() -> new Login_Page().setVisible(true)); // ✅ return to login
        }
    }

    private void showMessage(String message) {
        JOptionPane.showMessageDialog(frame, message);
    }
}
