import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.Vector;

public class BorrowBooksPage {
    private JFrame frame;
    private JTable table;
    private DefaultTableModel tableModel;
    private JComboBox<String> userDropdown;
    private JComboBox<String> isbnDropdown;
    private JTextField dateField;

    public static void showDashboard(String fullName) {
        SwingUtilities.invokeLater(BorrowBooksPage::new);
    }

    public BorrowBooksPage() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Borrow Books");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(1000, 600);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());

        tableModel = new DefaultTableModel(new String[]{"Borrow ID", "ID Number", "ISBN", "Book Title", "Borrowed Date"}, 0);
        table = new JTable(tableModel);
        table.setFont(new Font("Arial", Font.PLAIN, 16));
        table.setRowHeight(24);
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        JPanel inputPanel = new JPanel(new FlowLayout());

        userDropdown = new JComboBox<>();
        isbnDropdown = new JComboBox<>();
        dateField = new JTextField("YYYY-MM-DD", 10);
        JButton addRecordBtn = new JButton("Add Record");

        Font font = new Font("Arial", Font.PLAIN, 16);
        userDropdown.setFont(font);
        isbnDropdown.setFont(font);
        dateField.setFont(font);
        addRecordBtn.setFont(new Font("Arial", Font.BOLD, 16));

        dateField.setForeground(Color.GRAY);
        dateField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent e) {
                if (dateField.getText().equals("YYYY-MM-DD")) {
                    dateField.setText("");
                    dateField.setForeground(Color.BLACK);
                }
            }

            public void focusLost(java.awt.event.FocusEvent e) {
                if (dateField.getText().isEmpty()) {
                    dateField.setText("YYYY-MM-DD");
                    dateField.setForeground(Color.GRAY);
                }
            }
        });

        inputPanel.add(createStyledLabel("ID Number:"));
        inputPanel.add(userDropdown);
        inputPanel.add(createStyledLabel("ISBN:"));
        inputPanel.add(isbnDropdown);
        inputPanel.add(createStyledLabel("Borrowed Date:"));
        inputPanel.add(dateField);
        inputPanel.add(addRecordBtn);

        frame.add(inputPanel, BorderLayout.NORTH);

        addRecordBtn.addActionListener(e -> addRecord());
        loadUserIDs();
        loadISBNs();
        loadBorrowedBooks();

        frame.setVisible(true);
    }

    private JLabel createStyledLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 16));
        return label;
    }

    private void loadUserIDs() {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            PreparedStatement stmt = conn.prepareStatement("SELECT id FROM User");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                userDropdown.addItem(String.valueOf(rs.getInt("id")));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Error loading ID numbers: " + e.getMessage());
        }
    }

    private void loadISBNs() {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            PreparedStatement stmt = conn.prepareStatement("SELECT ISBN FROM LibraryMaterial WHERE Status = 'Available'");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                isbnDropdown.addItem(rs.getString("ISBN"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Error loading ISBNs: " + e.getMessage());
        }
    }

    private void addRecord() {
        String userIDText = (String) userDropdown.getSelectedItem();
        String isbn = (String) isbnDropdown.getSelectedItem();
        String borrowedDate = dateField.getText().trim();

        if (userIDText == null || isbn == null || borrowedDate.isEmpty() || borrowedDate.equals("YYYY-MM-DD")) {
            JOptionPane.showMessageDialog(frame, "Please complete all fields.");
            return;
        }

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO BorrowingList (StudentID, ISBN, BorrowedDate) VALUES (?, ?, ?)"
            );
            stmt.setInt(1, Integer.parseInt(userIDText));
            stmt.setString(2, isbn);
            stmt.setString(3, borrowedDate);
            stmt.executeUpdate();

            PreparedStatement updateStatus = conn.prepareStatement("UPDATE LibraryMaterial SET Status = 'Borrowed' WHERE ISBN = ?");
            updateStatus.setString(1, isbn);
            updateStatus.executeUpdate();

            JOptionPane.showMessageDialog(frame, "Book successfully borrowed.");
            loadBorrowedBooks();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Error adding record: " + e.getMessage());
        }
    }

    private void loadBorrowedBooks() {
        tableModel.setRowCount(0);
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            String query = "SELECT b.BorrowID, u.id AS UserID, b.ISBN, l.BookName, b.BorrowedDate " +
                    "FROM BorrowingList b " +
                    "JOIN User u ON b.StudentID = u.id " +
                    "JOIN LibraryMaterial l ON b.ISBN = l.ISBN";

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getInt("BorrowID"));
                row.add(rs.getInt("UserID"));
                row.add(rs.getString("ISBN"));
                row.add(rs.getString("BookName"));
                row.add(rs.getDate("BorrowedDate"));
                tableModel.addRow(row);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Error loading borrowed books: " + e.getMessage());
        }
    }
}
