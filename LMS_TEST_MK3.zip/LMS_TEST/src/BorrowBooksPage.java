/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Princess
 */
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class BorrowBooksPage {
    private JFrame frame;
    private JTable table;
    private DefaultTableModel model;

    public BorrowBooksPage() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Borrowed Books Status");
        frame.setSize(1000, 600);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        JLabel header = new JLabel("Borrowed Books", SwingConstants.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 20));
        header.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        frame.add(header, BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"Borrow ID", "Student ID", "Book Title", "Borrow Date"}, 0);
        table = new JTable(model);
        table.setRowHeight(25);
        loadBorrowedBooks();

        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        JButton addRecordBtn = new JButton("Add Borrow Record");
        addRecordBtn.setFont(new Font("Arial", Font.BOLD, 14));
        addRecordBtn.setBackground(Color.BLUE);
        addRecordBtn.setForeground(Color.WHITE);
        addRecordBtn.addActionListener(e -> addBorrowRecord());

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(new Color(220, 220, 220));
        bottomPanel.add(addRecordBtn);
        frame.add(bottomPanel, BorderLayout.SOUTH);

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void loadBorrowedBooks() {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            String sql = "SELECT BorrowID, StudentID, BookTitle, BorrowDate FROM BorrowedBooks";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            model.setRowCount(0);
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("BorrowID"),
                        rs.getInt("StudentID"),
                        rs.getString("BookTitle"),
                        rs.getDate("BorrowDate")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Database error: " + e.getMessage());
        }
    }

    private void addBorrowRecord() {
        JTextField studentIDField = new JTextField();
        JTextField bookTitleField = new JTextField();
        JPanel panel = new JPanel(new GridLayout(0, 1));
        panel.add(new JLabel("Student ID:"));
        panel.add(studentIDField);
        panel.add(new JLabel("Book Title:"));
        panel.add(bookTitleField);

        int result = JOptionPane.showConfirmDialog(frame, panel, "Add Borrow Record", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
                String sql = "INSERT INTO BorrowedBooks (StudentID, BookTitle, BorrowDate) VALUES (?, ?, CURRENT_DATE)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setInt(1, Integer.parseInt(studentIDField.getText()));
                stmt.setString(2, bookTitleField.getText());
                stmt.executeUpdate();
                loadBorrowedBooks();
                JOptionPane.showMessageDialog(frame, "Record added successfully.");
            } catch (SQLException | NumberFormatException e) {
                JOptionPane.showMessageDialog(frame, "Error: " + e.getMessage());
            }
        }
    }
}
