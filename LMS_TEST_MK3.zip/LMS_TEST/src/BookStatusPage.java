import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.net.URL;
import java.sql.*;

public class BookStatusPage {

    private JFrame frame;
    private JTable table;
    private DefaultTableModel tableModel;
    private String fullName;

    public static void showDashboard(String fullName) {
        SwingUtilities.invokeLater(() -> new BookStatusPage(fullName));
    }

    public BookStatusPage(String fullName) {
        this.fullName = fullName;
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Book Status");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(1100, 700);
        frame.setLayout(new BorderLayout());

        frame.add(createSidebarPanel(), BorderLayout.WEST);
        frame.add(createMainPanel(), BorderLayout.CENTER);

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private JPanel createSidebarPanel() {
        JPanel sidebar = new JPanel();
        sidebar.setBackground(Color.DARK_GRAY);
        sidebar.setPreferredSize(new Dimension(250, frame.getHeight()));
        sidebar.setLayout(new BorderLayout());

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
        topPanel.setBackground(Color.DARK_GRAY);

        JLabel title = new JLabel("DASHBOARD", SwingConstants.CENTER);
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        topPanel.add(title);

        try {
            URL logoUrl = getClass().getResource("mapua_logo.png");
            if (logoUrl != null) {
                ImageIcon originalIcon = new ImageIcon(logoUrl);
                Image scaledImage = originalIcon.getImage().getScaledInstance(150, 100, Image.SCALE_SMOOTH);
                JLabel logo = new JLabel(new ImageIcon(scaledImage));
                logo.setAlignmentX(Component.CENTER_ALIGNMENT);
                JPanel logoPanel = new JPanel();
                logoPanel.setBackground(Color.DARK_GRAY);
                logoPanel.add(logo);
                topPanel.add(logoPanel);
            }
        } catch (Exception e) {
            System.err.println("Error loading logo: " + e.getMessage());
        }

        JPanel centerPanel = new JPanel();
        centerPanel.setBackground(Color.DARK_GRAY);
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(100, 20, 100, 20));

        JButton manageBooksBtn = createSidebarButton("Manage Books");
        JButton bookStatusBtn = createSidebarButton("Book Status");
        JButton manageAccountsBtn = createSidebarButton("Manage Accounts");

        centerPanel.add(manageBooksBtn);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        centerPanel.add(bookStatusBtn);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        centerPanel.add(manageAccountsBtn);

        JPanel logoutPanel = new JPanel();
        logoutPanel.setBackground(Color.DARK_GRAY);
        logoutPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        logoutPanel.setLayout(new BoxLayout(logoutPanel, BoxLayout.Y_AXIS));

        JButton logoutBtn = new JButton("LOGOUT");
        logoutBtn.setFont(new Font("Arial", Font.BOLD, 16));
        logoutBtn.setMaximumSize(new Dimension(200, 40));
        logoutBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoutBtn.setBackground(Color.WHITE);
        logoutBtn.setFocusPainted(false);
        logoutBtn.addActionListener(e -> frame.dispose());

        logoutPanel.add(logoutBtn);

        sidebar.add(topPanel, BorderLayout.NORTH);
        sidebar.add(centerPanel, BorderLayout.CENTER);
        sidebar.add(logoutPanel, BorderLayout.SOUTH);

        manageBooksBtn.addActionListener(e -> {
            frame.dispose();
            LibrarianDashboard.showDashboard(fullName);
        });

        bookStatusBtn.addActionListener(e -> {
            frame.dispose();
            new BookStatusPage(fullName);
        });

        manageAccountsBtn.addActionListener(e -> JOptionPane.showMessageDialog(frame, "Manage Accounts clicked"));

        return sidebar;
    }

    private JButton createSidebarButton(String text) {
        JButton button = new JButton(text);
        button.setMaximumSize(new Dimension(200, 40));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setFont(new Font("Arial", Font.PLAIN, 16));
        button.setFocusPainted(false);
        return button;
    }

    private JPanel createMainPanel() {
        JPanel panel = new JPanel();
        panel.setBackground(new Color(190, 186, 186));
        panel.setLayout(new BorderLayout());

        JPanel topPanel = new JPanel();
        topPanel.setBackground(new Color(190, 186, 186));
        topPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 30));

        JTextField searchField = new JTextField(40);
        searchField.setPreferredSize(new Dimension(400, 30));
        JButton searchBtn = new JButton("Search");
        searchBtn.setPreferredSize(new Dimension(100, 30));
        searchBtn.setFont(new Font("Arial", Font.BOLD, 14));

        topPanel.add(searchField);
        topPanel.add(searchBtn);

        JPanel tabPanel = new JPanel();
        tabPanel.setBackground(new Color(190, 186, 186));
        tabPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 60, 10));

        JButton availableBtn = new JButton("Available Books");
        JButton borrowBtn = new JButton("Borrow Books");
        JButton returnBtn = new JButton("Return Books");

        for (JButton btn : new JButton[]{availableBtn, borrowBtn, returnBtn}) {
            btn.setFont(new Font("Arial", Font.BOLD, 14));
            btn.setPreferredSize(new Dimension(140, 30));
            btn.setFocusPainted(false);
        }

        tabPanel.add(availableBtn);
        tabPanel.add(borrowBtn);
        tabPanel.add(returnBtn);

        String[] columnNames = {"ISBN", "Book Title", "Author", "Category", "Publisher", "Publish Date"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(table);

        JPanel topCombined = new JPanel();
        topCombined.setLayout(new BorderLayout());
        topCombined.setBackground(new Color(190, 186, 186));
        topCombined.add(topPanel, BorderLayout.NORTH);
        topCombined.add(tabPanel, BorderLayout.CENTER);

        panel.add(topCombined, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);

        loadAvailableBooks();

        searchBtn.addActionListener(e -> {
            String keyword = searchField.getText().trim();
            if (keyword.isEmpty()) {
                loadAvailableBooks();
            }
        });

        return panel;
    }

    private void loadAvailableBooks() {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibrarySystem", "root", "root")) {
            String query = "SELECT ISBN, BookName, Authors, CategoryName, Publisher, PublishedDate " +
                           "FROM LibraryMaterial WHERE Status = 'Available'";

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            tableModel.setRowCount(0);

            while (rs.next()) {
                Object[] row = {
                    rs.getString("ISBN"),
                    rs.getString("BookName"),
                    rs.getString("Authors"),
                    rs.getString("CategoryName"),
                    rs.getString("Publisher"),
                    rs.getDate("PublishedDate")
                };
                tableModel.addRow(row);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Database error: " + e.getMessage());
        }
    }
}